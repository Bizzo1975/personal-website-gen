--
-- PostgreSQL database dump
--

\restrict kjghHhrwURYiYxX5fpyK2H0QdJyINfS5l1AbwPUiRieyHVEO77QGnFS44IlqgDX

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

-- Started on 2025-10-24 20:24:34 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_role_history DROP CONSTRAINT IF EXISTS user_role_history_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_role_history DROP CONSTRAINT IF EXISTS user_role_history_changed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.user_permissions DROP CONSTRAINT IF EXISTS user_permissions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_permissions DROP CONSTRAINT IF EXISTS user_permissions_granted_by_fkey;
ALTER TABLE IF EXISTS ONLY public.user_login_sessions DROP CONSTRAINT IF EXISTS user_login_sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_activity_log DROP CONSTRAINT IF EXISTS user_activity_log_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_access_levels DROP CONSTRAINT IF EXISTS user_access_levels_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_access_levels DROP CONSTRAINT IF EXISTS user_access_levels_granted_by_fkey;
ALTER TABLE IF EXISTS ONLY public.user_2fa_settings DROP CONSTRAINT IF EXISTS user_2fa_settings_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.security_logs DROP CONSTRAINT IF EXISTS security_logs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_last_edited_by_fkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.posts DROP CONSTRAINT IF EXISTS posts_last_edited_by_fkey;
ALTER TABLE IF EXISTS ONLY public.posts DROP CONSTRAINT IF EXISTS posts_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_templates DROP CONSTRAINT IF EXISTS newsletter_templates_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_campaigns DROP CONSTRAINT IF EXISTS newsletter_campaigns_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_campaigns DROP CONSTRAINT IF EXISTS newsletter_campaigns_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_automation_rules DROP CONSTRAINT IF EXISTS newsletter_automation_rules_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_automation_rules DROP CONSTRAINT IF EXISTS newsletter_automation_rules_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_analytics DROP CONSTRAINT IF EXISTS newsletter_analytics_subscriber_id_fkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_analytics DROP CONSTRAINT IF EXISTS newsletter_analytics_campaign_id_fkey;
ALTER TABLE IF EXISTS ONLY public.media_folders DROP CONSTRAINT IF EXISTS media_folders_parent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.media_files DROP CONSTRAINT IF EXISTS media_files_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.content_versions DROP CONSTRAINT IF EXISTS content_versions_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.content_drafts DROP CONSTRAINT IF EXISTS content_drafts_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.content_comments DROP CONSTRAINT IF EXISTS content_comments_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.content_collaborators DROP CONSTRAINT IF EXISTS content_collaborators_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.content_collaborators DROP CONSTRAINT IF EXISTS content_collaborators_invited_by_fkey;
ALTER TABLE IF EXISTS ONLY public.bulk_operations_log DROP CONSTRAINT IF EXISTS bulk_operations_log_performed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.access_requests DROP CONSTRAINT IF EXISTS access_requests_processed_by_fkey;
DROP TRIGGER IF EXISTS update_user_2fa_settings_updated_at ON public.user_2fa_settings;
DROP TRIGGER IF EXISTS update_roles_updated_at ON public.roles;
DROP TRIGGER IF EXISTS update_projects_updated_at ON public.projects;
DROP TRIGGER IF EXISTS update_projects_last_edited_at ON public.projects;
DROP TRIGGER IF EXISTS update_profiles_updated_at ON public.profiles;
DROP TRIGGER IF EXISTS update_posts_updated_at ON public.posts;
DROP TRIGGER IF EXISTS update_posts_last_edited_at ON public.posts;
DROP TRIGGER IF EXISTS update_pages_updated_at ON public.pages;
DROP TRIGGER IF EXISTS update_newsletter_templates_updated_at ON public.newsletter_templates;
DROP TRIGGER IF EXISTS update_newsletter_content_updated_at ON public.newsletter_content;
DROP TRIGGER IF EXISTS update_content_templates_updated_at ON public.content_templates;
DROP TRIGGER IF EXISTS update_content_drafts_updated_at ON public.content_drafts;
DROP TRIGGER IF EXISTS update_content_comments_updated_at ON public.content_comments;
DROP TRIGGER IF EXISTS update_categories_updated_at ON public.categories;
DROP INDEX IF EXISTS public.idx_verification_tokens_token;
DROP INDEX IF EXISTS public.idx_user_role_history_user_id;
DROP INDEX IF EXISTS public.idx_user_permissions_user_id;
DROP INDEX IF EXISTS public.idx_user_permissions_permission_name;
DROP INDEX IF EXISTS public.idx_user_login_sessions_user_id;
DROP INDEX IF EXISTS public.idx_user_login_sessions_expires_at;
DROP INDEX IF EXISTS public.idx_user_activity_log_user_id;
DROP INDEX IF EXISTS public.idx_user_activity_log_created_at;
DROP INDEX IF EXISTS public.idx_user_activity_log_action;
DROP INDEX IF EXISTS public.idx_user_access_levels_professional;
DROP INDEX IF EXISTS public.idx_user_access_levels_personal;
DROP INDEX IF EXISTS public.idx_user_access_levels_email;
DROP INDEX IF EXISTS public.idx_sessions_user_id;
DROP INDEX IF EXISTS public.idx_sessions_session_token;
DROP INDEX IF EXISTS public.idx_security_logs_user_id;
DROP INDEX IF EXISTS public.idx_security_logs_created_at;
DROP INDEX IF EXISTS public.idx_projects_status;
DROP INDEX IF EXISTS public.idx_projects_slug;
DROP INDEX IF EXISTS public.idx_projects_permission_level;
DROP INDEX IF EXISTS public.idx_projects_last_edited;
DROP INDEX IF EXISTS public.idx_projects_featured;
DROP INDEX IF EXISTS public.idx_profiles_home_page_skills;
DROP INDEX IF EXISTS public.idx_posts_status;
DROP INDEX IF EXISTS public.idx_posts_slug;
DROP INDEX IF EXISTS public.idx_posts_published;
DROP INDEX IF EXISTS public.idx_posts_permission_level;
DROP INDEX IF EXISTS public.idx_posts_last_edited;
DROP INDEX IF EXISTS public.idx_posts_date;
DROP INDEX IF EXISTS public.idx_pages_slug;
DROP INDEX IF EXISTS public.idx_newsletter_subscribers_source;
DROP INDEX IF EXISTS public.idx_newsletter_subscribers_email;
DROP INDEX IF EXISTS public.idx_newsletter_subscribers_active;
DROP INDEX IF EXISTS public.idx_newsletter_campaigns_type;
DROP INDEX IF EXISTS public.idx_newsletter_campaigns_status;
DROP INDEX IF EXISTS public.idx_newsletter_campaigns_scheduled;
DROP INDEX IF EXISTS public.idx_newsletter_automation_rules_next_run;
DROP INDEX IF EXISTS public.idx_newsletter_automation_rules_active;
DROP INDEX IF EXISTS public.idx_newsletter_analytics_subscriber;
DROP INDEX IF EXISTS public.idx_newsletter_analytics_event_type;
DROP INDEX IF EXISTS public.idx_newsletter_analytics_created_at;
DROP INDEX IF EXISTS public.idx_newsletter_analytics_campaign;
DROP INDEX IF EXISTS public.idx_media_folders_parent;
DROP INDEX IF EXISTS public.idx_media_files_updated_at;
DROP INDEX IF EXISTS public.idx_media_files_tags;
DROP INDEX IF EXISTS public.idx_media_files_starred;
DROP INDEX IF EXISTS public.idx_media_files_folder;
DROP INDEX IF EXISTS public.idx_content_versions_content_type;
DROP INDEX IF EXISTS public.idx_content_versions_content_id;
DROP INDEX IF EXISTS public.idx_content_drafts_updated_at;
DROP INDEX IF EXISTS public.idx_content_drafts_type;
DROP INDEX IF EXISTS public.idx_content_drafts_created_by;
DROP INDEX IF EXISTS public.idx_content_drafts_content_id;
DROP INDEX IF EXISTS public.idx_content_comments_content_id;
DROP INDEX IF EXISTS public.idx_content_collaborators_user_id;
DROP INDEX IF EXISTS public.idx_content_collaborators_content_id;
DROP INDEX IF EXISTS public.idx_categories_slug;
DROP INDEX IF EXISTS public.idx_bulk_operations_log_performed_by;
DROP INDEX IF EXISTS public.idx_accounts_user_id;
DROP INDEX IF EXISTS public.idx_accounts_provider;
DROP INDEX IF EXISTS public.idx_access_requests_status;
DROP INDEX IF EXISTS public.idx_access_requests_email;
ALTER TABLE IF EXISTS ONLY public.verification_tokens DROP CONSTRAINT IF EXISTS verification_tokens_token_key;
ALTER TABLE IF EXISTS ONLY public.verification_tokens DROP CONSTRAINT IF EXISTS verification_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_role_history DROP CONSTRAINT IF EXISTS user_role_history_pkey;
ALTER TABLE IF EXISTS ONLY public.user_permissions DROP CONSTRAINT IF EXISTS user_permissions_user_id_permission_name_key;
ALTER TABLE IF EXISTS ONLY public.user_permissions DROP CONSTRAINT IF EXISTS user_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.user_login_sessions DROP CONSTRAINT IF EXISTS user_login_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.user_activity_log DROP CONSTRAINT IF EXISTS user_activity_log_pkey;
ALTER TABLE IF EXISTS ONLY public.user_access_levels DROP CONSTRAINT IF EXISTS user_access_levels_pkey;
ALTER TABLE IF EXISTS ONLY public.user_access_levels DROP CONSTRAINT IF EXISTS user_access_levels_email_key;
ALTER TABLE IF EXISTS ONLY public.user_2fa_settings DROP CONSTRAINT IF EXISTS user_2fa_settings_user_id_key;
ALTER TABLE IF EXISTS ONLY public.user_2fa_settings DROP CONSTRAINT IF EXISTS user_2fa_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.site_settings DROP CONSTRAINT IF EXISTS site_settings_setting_key_key;
ALTER TABLE IF EXISTS ONLY public.site_settings DROP CONSTRAINT IF EXISTS site_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_session_token_key;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.security_logs DROP CONSTRAINT IF EXISTS security_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_name_key;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_slug_key;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_pkey;
ALTER TABLE IF EXISTS ONLY public.profiles DROP CONSTRAINT IF EXISTS profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.posts DROP CONSTRAINT IF EXISTS posts_slug_key;
ALTER TABLE IF EXISTS ONLY public.posts DROP CONSTRAINT IF EXISTS posts_pkey;
ALTER TABLE IF EXISTS ONLY public.pages DROP CONSTRAINT IF EXISTS pages_slug_key;
ALTER TABLE IF EXISTS ONLY public.pages DROP CONSTRAINT IF EXISTS pages_pkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_templates DROP CONSTRAINT IF EXISTS newsletter_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_subscribers DROP CONSTRAINT IF EXISTS newsletter_subscribers_pkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_subscribers DROP CONSTRAINT IF EXISTS newsletter_subscribers_email_key;
ALTER TABLE IF EXISTS ONLY public.newsletter_content DROP CONSTRAINT IF EXISTS newsletter_content_pkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_campaigns DROP CONSTRAINT IF EXISTS newsletter_campaigns_slug_key;
ALTER TABLE IF EXISTS ONLY public.newsletter_campaigns DROP CONSTRAINT IF EXISTS newsletter_campaigns_pkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_automation_rules DROP CONSTRAINT IF EXISTS newsletter_automation_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_analytics DROP CONSTRAINT IF EXISTS newsletter_analytics_pkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_analytics DROP CONSTRAINT IF EXISTS newsletter_analytics_campaign_id_subscriber_id_event_type_c_key;
ALTER TABLE IF EXISTS ONLY public.media_folders DROP CONSTRAINT IF EXISTS media_folders_pkey;
ALTER TABLE IF EXISTS ONLY public.media_files DROP CONSTRAINT IF EXISTS media_files_pkey;
ALTER TABLE IF EXISTS ONLY public.content_versions DROP CONSTRAINT IF EXISTS content_versions_pkey;
ALTER TABLE IF EXISTS ONLY public.content_versions DROP CONSTRAINT IF EXISTS content_versions_content_id_version_number_key;
ALTER TABLE IF EXISTS ONLY public.content_templates DROP CONSTRAINT IF EXISTS content_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.content_drafts DROP CONSTRAINT IF EXISTS content_drafts_pkey;
ALTER TABLE IF EXISTS ONLY public.content_drafts DROP CONSTRAINT IF EXISTS content_drafts_content_type_content_id_key;
ALTER TABLE IF EXISTS ONLY public.content_comments DROP CONSTRAINT IF EXISTS content_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.content_collaborators DROP CONSTRAINT IF EXISTS content_collaborators_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_slug_key;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.bulk_operations_log DROP CONSTRAINT IF EXISTS bulk_operations_log_pkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_pkey;
ALTER TABLE IF EXISTS ONLY public.access_requests DROP CONSTRAINT IF EXISTS access_requests_pkey;
ALTER TABLE IF EXISTS public.media_folders ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.verification_tokens;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_role_history;
DROP TABLE IF EXISTS public.user_permissions;
DROP TABLE IF EXISTS public.user_login_sessions;
DROP TABLE IF EXISTS public.user_activity_log;
DROP TABLE IF EXISTS public.user_access_levels;
DROP TABLE IF EXISTS public.user_2fa_settings;
DROP TABLE IF EXISTS public.site_settings;
DROP TABLE IF EXISTS public.sessions;
DROP TABLE IF EXISTS public.security_logs;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.projects;
DROP TABLE IF EXISTS public.profiles;
DROP TABLE IF EXISTS public.posts;
DROP TABLE IF EXISTS public.pages;
DROP TABLE IF EXISTS public.newsletter_templates;
DROP TABLE IF EXISTS public.newsletter_subscribers;
DROP TABLE IF EXISTS public.newsletter_content;
DROP TABLE IF EXISTS public.newsletter_campaigns;
DROP TABLE IF EXISTS public.newsletter_automation_rules;
DROP TABLE IF EXISTS public.newsletter_analytics;
DROP SEQUENCE IF EXISTS public.media_folders_id_seq;
DROP TABLE IF EXISTS public.media_folders;
DROP TABLE IF EXISTS public.media_files;
DROP TABLE IF EXISTS public.content_versions;
DROP TABLE IF EXISTS public.content_templates;
DROP TABLE IF EXISTS public.content_drafts;
DROP TABLE IF EXISTS public.content_comments;
DROP TABLE IF EXISTS public.content_collaborators;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.bulk_operations_log;
DROP TABLE IF EXISTS public.accounts;
DROP TABLE IF EXISTS public.access_requests;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP FUNCTION IF EXISTS public.update_last_edited_at();
DROP EXTENSION IF EXISTS "uuid-ossp";
--
-- TOC entry 2 (class 3079 OID 24576)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 3976 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 270 (class 1255 OID 24587)
-- Name: update_last_edited_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_last_edited_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.last_edited_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_last_edited_at() OWNER TO postgres;

--
-- TOC entry 271 (class 1255 OID 24588)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 215 (class 1259 OID 24589)
-- Name: access_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    subject character varying(500),
    message text NOT NULL,
    request_type character varying(50) DEFAULT 'access_request'::character varying,
    requested_access_level character varying(50) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    submitted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    processed_at timestamp without time zone,
    processed_by uuid,
    admin_notes text,
    CONSTRAINT access_requests_request_type_check CHECK (((request_type)::text = ANY (ARRAY[('contact'::character varying)::text, ('access_request'::character varying)::text]))),
    CONSTRAINT access_requests_requested_access_level_check CHECK (((requested_access_level)::text = ANY (ARRAY[('professional'::character varying)::text, ('personal'::character varying)::text]))),
    CONSTRAINT access_requests_status_check CHECK (((status)::text = ANY (ARRAY[('pending'::character varying)::text, ('approved'::character varying)::text, ('rejected'::character varying)::text])))
);


ALTER TABLE public.access_requests OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 24601)
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    type character varying(255) NOT NULL,
    provider character varying(255) NOT NULL,
    provider_account_id character varying(255) NOT NULL,
    refresh_token text,
    access_token text,
    expires_at bigint,
    id_token text,
    scope text,
    session_state text,
    token_type text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 24609)
-- Name: bulk_operations_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bulk_operations_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    operation_type character varying(50) NOT NULL,
    target_type character varying(50) NOT NULL,
    target_ids uuid[],
    parameters jsonb,
    status character varying(20) DEFAULT 'pending'::character varying,
    total_items integer DEFAULT 0,
    processed_items integer DEFAULT 0,
    errors text[],
    performed_by uuid,
    started_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone,
    CONSTRAINT bulk_operations_log_status_check CHECK (((status)::text = ANY (ARRAY[('pending'::character varying)::text, ('processing'::character varying)::text, ('completed'::character varying)::text, ('failed'::character varying)::text])))
);


ALTER TABLE public.bulk_operations_log OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 24620)
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    color character varying(7) DEFAULT '#3B82F6'::character varying,
    post_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 24630)
-- Name: content_collaborators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.content_collaborators (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    content_id uuid NOT NULL,
    content_type character varying(50) NOT NULL,
    user_id uuid,
    user_email character varying(255) NOT NULL,
    permission_level character varying(20) DEFAULT 'editor'::character varying,
    invited_by uuid,
    invited_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    accepted_at timestamp without time zone,
    status character varying(20) DEFAULT 'pending'::character varying,
    CONSTRAINT content_collaborators_content_type_check CHECK (((content_type)::text = ANY (ARRAY[('post'::character varying)::text, ('project'::character varying)::text, ('page'::character varying)::text]))),
    CONSTRAINT content_collaborators_permission_level_check CHECK (((permission_level)::text = ANY (ARRAY[('viewer'::character varying)::text, ('editor'::character varying)::text, ('owner'::character varying)::text]))),
    CONSTRAINT content_collaborators_status_check CHECK (((status)::text = ANY (ARRAY[('pending'::character varying)::text, ('accepted'::character varying)::text, ('rejected'::character varying)::text])))
);


ALTER TABLE public.content_collaborators OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 24640)
-- Name: content_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.content_comments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    content_id uuid NOT NULL,
    content_type character varying(50) NOT NULL,
    user_id uuid,
    user_email character varying(255) NOT NULL,
    comment text NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT content_comments_content_type_check CHECK (((content_type)::text = ANY (ARRAY[('post'::character varying)::text, ('project'::character varying)::text, ('page'::character varying)::text]))),
    CONSTRAINT content_comments_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('resolved'::character varying)::text, ('deleted'::character varying)::text])))
);


ALTER TABLE public.content_comments OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 24651)
-- Name: content_drafts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.content_drafts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    content_type character varying(20) NOT NULL,
    content_id uuid NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_by uuid NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    auto_save boolean DEFAULT false,
    version integer DEFAULT 1,
    CONSTRAINT content_drafts_content_type_check CHECK (((content_type)::text = ANY (ARRAY[('project'::character varying)::text, ('post'::character varying)::text, ('page'::character varying)::text])))
);


ALTER TABLE public.content_drafts OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 24663)
-- Name: content_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.content_templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    content text NOT NULL,
    variables text[],
    usage_count integer DEFAULT 0,
    author character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT content_templates_type_check CHECK (((type)::text = ANY (ARRAY[('post'::character varying)::text, ('project'::character varying)::text, ('page'::character varying)::text, ('newsletter'::character varying)::text])))
);


ALTER TABLE public.content_templates OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 24673)
-- Name: content_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.content_versions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    content_id uuid NOT NULL,
    content_type character varying(50) NOT NULL,
    version_number integer NOT NULL,
    title character varying(500) NOT NULL,
    content text NOT NULL,
    changes_summary text,
    created_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_current boolean DEFAULT false,
    CONSTRAINT content_versions_content_type_check CHECK (((content_type)::text = ANY (ARRAY[('post'::character varying)::text, ('project'::character varying)::text, ('page'::character varying)::text])))
);


ALTER TABLE public.content_versions OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 24682)
-- Name: media_files; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media_files (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    filename character varying(500) NOT NULL,
    original_name character varying(500) NOT NULL,
    file_path character varying(1000) NOT NULL,
    file_size bigint,
    mime_type character varying(100),
    content_type character varying(50),
    alt_text text,
    uploaded_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    starred boolean DEFAULT false,
    tags jsonb DEFAULT '[]'::jsonb,
    folder character varying(255) DEFAULT NULL::character varying,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT media_files_content_type_check CHECK (((content_type)::text = ANY (ARRAY[('post'::character varying)::text, ('project'::character varying)::text, ('newsletter'::character varying)::text, ('general'::character varying)::text])))
);


ALTER TABLE public.media_files OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 24694)
-- Name: media_folders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media_folders (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    parent_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.media_folders OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 24699)
-- Name: media_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.media_folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.media_folders_id_seq OWNER TO postgres;

--
-- TOC entry 3978 (class 0 OID 0)
-- Dependencies: 226
-- Name: media_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.media_folders_id_seq OWNED BY public.media_folders.id;


--
-- TOC entry 227 (class 1259 OID 24700)
-- Name: newsletter_analytics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.newsletter_analytics (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    campaign_id uuid,
    subscriber_id uuid,
    email character varying(255) NOT NULL,
    event_type character varying(50) NOT NULL,
    event_data jsonb DEFAULT '{}'::jsonb,
    user_agent text,
    ip_address character varying(45),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT newsletter_analytics_event_type_check CHECK (((event_type)::text = ANY (ARRAY[('sent'::character varying)::text, ('delivered'::character varying)::text, ('opened'::character varying)::text, ('clicked'::character varying)::text, ('bounced'::character varying)::text, ('unsubscribed'::character varying)::text, ('complained'::character varying)::text])))
);


ALTER TABLE public.newsletter_analytics OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 24709)
-- Name: newsletter_automation_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.newsletter_automation_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    type character varying(50) NOT NULL,
    is_active boolean DEFAULT true,
    trigger_conditions jsonb NOT NULL,
    template_id uuid,
    schedule_config jsonb DEFAULT '{}'::jsonb,
    target_criteria jsonb DEFAULT '{}'::jsonb,
    last_run_at timestamp without time zone,
    next_run_at timestamp without time zone,
    created_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT newsletter_automation_rules_type_check CHECK (((type)::text = ANY (ARRAY[('monthly_digest'::character varying)::text, ('welcome_series'::character varying)::text, ('content_trigger'::character varying)::text, ('custom'::character varying)::text])))
);


ALTER TABLE public.newsletter_automation_rules OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 24721)
-- Name: newsletter_campaigns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.newsletter_campaigns (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(255) NOT NULL,
    subject character varying(500) NOT NULL,
    preview_text character varying(200),
    content text NOT NULL,
    html_content text,
    plain_text_content text,
    template_id uuid,
    status character varying(50) DEFAULT 'draft'::character varying,
    type character varying(50) NOT NULL,
    permissions jsonb DEFAULT '{"level": "all", "customRules": [], "allowedRoles": ["admin", "editor", "author", "subscriber", "guest"], "allowedUsers": [], "requiresAuth": false, "restrictedUsers": []}'::jsonb,
    target_access_levels text[] DEFAULT ARRAY['all'::text],
    scheduled_send_at timestamp without time zone,
    sent_at timestamp without time zone,
    recipient_count integer DEFAULT 0,
    author character varying(255) DEFAULT 'admin'::character varying,
    created_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT newsletter_campaigns_status_check CHECK (((status)::text = ANY (ARRAY[('draft'::character varying)::text, ('scheduled'::character varying)::text, ('sending'::character varying)::text, ('sent'::character varying)::text, ('cancelled'::character varying)::text, ('failed'::character varying)::text]))),
    CONSTRAINT newsletter_campaigns_type_check CHECK (((type)::text = ANY (ARRAY[('manual'::character varying)::text, ('automated'::character varying)::text, ('welcome'::character varying)::text, ('announcement'::character varying)::text])))
);


ALTER TABLE public.newsletter_campaigns OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 24736)
-- Name: newsletter_content; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.newsletter_content (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    incentive text,
    subscriber_count integer DEFAULT 0,
    footer_text text,
    weekly_articles_icon character varying(50) DEFAULT 'document'::character varying,
    weekly_articles_title character varying(100) DEFAULT 'Weekly Articles'::character varying,
    weekly_articles_description text DEFAULT 'In-depth tutorials and insights'::text,
    exclusive_tips_icon character varying(50) DEFAULT 'bolt'::character varying,
    exclusive_tips_title character varying(100) DEFAULT 'Exclusive Tips'::character varying,
    exclusive_tips_description text DEFAULT 'Subscriber-only content and resources'::text,
    early_access_icon character varying(50) DEFAULT 'clock'::character varying,
    early_access_title character varying(100) DEFAULT 'Early Access'::character varying,
    early_access_description text DEFAULT 'Be first to see new projects and posts'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.newsletter_content OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 24754)
-- Name: newsletter_subscribers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.newsletter_subscribers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    phone character varying(50),
    company character varying(255),
    interests text[],
    subscription_source character varying(100) DEFAULT 'website'::character varying,
    subscription_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true,
    is_confirmed boolean DEFAULT true,
    unsubscribe_token uuid DEFAULT public.uuid_generate_v4(),
    unsubscribed_at timestamp without time zone,
    unsubscribe_reason text,
    preferences jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.newsletter_subscribers OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 24769)
-- Name: newsletter_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.newsletter_templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    template_html text NOT NULL,
    template_variables text[],
    is_default boolean DEFAULT false,
    usage_count integer DEFAULT 0,
    created_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    type character varying(50) DEFAULT 'custom'::character varying,
    html_content text,
    plain_text_content text,
    subject_template character varying(500),
    preview_text_template character varying(200),
    variables jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    is_system boolean DEFAULT false
);


ALTER TABLE public.newsletter_templates OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 24783)
-- Name: pages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(255) NOT NULL,
    content text NOT NULL,
    meta_description text,
    header_title character varying(500),
    header_subtitle text,
    hero_heading character varying(500),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    connect_section_title character varying(255),
    connect_section_content text,
    form_section_title character varying(255),
    form_description text
);


ALTER TABLE public.pages OWNER TO postgres;

--
-- TOC entry 234 (class 1259 OID 24791)
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(255) NOT NULL,
    content text NOT NULL,
    excerpt text,
    featured_image character varying(500),
    tags text[],
    author character varying(255) DEFAULT 'Anonymous'::character varying,
    read_time integer DEFAULT 5,
    date date DEFAULT CURRENT_DATE NOT NULL,
    permission_level character varying(50) DEFAULT 'all'::character varying,
    status character varying(50) DEFAULT 'draft'::character varying,
    scheduled_publish_at timestamp without time zone,
    published_at timestamp without time zone,
    published boolean DEFAULT false,
    created_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    draft_content text,
    last_edited_by uuid,
    last_edited_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    featured boolean DEFAULT false,
    CONSTRAINT posts_permission_level_check CHECK (((permission_level)::text = ANY (ARRAY[('all'::character varying)::text, ('professional'::character varying)::text, ('personal'::character varying)::text]))),
    CONSTRAINT posts_status_check CHECK (((status)::text = ANY (ARRAY[('draft'::character varying)::text, ('scheduled'::character varying)::text, ('published'::character varying)::text])))
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 24809)
-- Name: profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profiles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    image_url character varying(500),
    skills text[],
    location character varying(255),
    email character varying(255),
    bio text,
    social_links jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    home_page_skills jsonb DEFAULT '[]'::jsonb
);


ALTER TABLE public.profiles OWNER TO postgres;

--
-- TOC entry 236 (class 1259 OID 24818)
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(255) NOT NULL,
    description text NOT NULL,
    content text,
    image character varying(500),
    technologies text[] NOT NULL,
    live_demo character varying(500),
    source_code character varying(500),
    featured boolean DEFAULT false,
    permission_level character varying(50) DEFAULT 'all'::character varying,
    status character varying(50) DEFAULT 'draft'::character varying,
    scheduled_publish_at timestamp without time zone,
    published_at timestamp without time zone,
    created_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    draft_content text,
    last_edited_by uuid,
    last_edited_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT projects_permission_level_check CHECK (((permission_level)::text = ANY (ARRAY[('all'::character varying)::text, ('professional'::character varying)::text, ('personal'::character varying)::text]))),
    CONSTRAINT projects_status_check CHECK (((status)::text = ANY (ARRAY[('draft'::character varying)::text, ('scheduled'::character varying)::text, ('published'::character varying)::text])))
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 24832)
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(50) NOT NULL,
    display_name character varying(100) NOT NULL,
    description text,
    permissions text[] NOT NULL,
    is_system boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- TOC entry 238 (class 1259 OID 24841)
-- Name: security_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.security_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    user_email character varying(255),
    action character varying(100) NOT NULL,
    details text,
    ip_address inet,
    user_agent text,
    status character varying(20) DEFAULT 'success'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT security_logs_status_check CHECK (((status)::text = ANY (ARRAY[('success'::character varying)::text, ('warning'::character varying)::text, ('error'::character varying)::text])))
);


ALTER TABLE public.security_logs OWNER TO postgres;

--
-- TOC entry 239 (class 1259 OID 24850)
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    session_token character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    expires timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- TOC entry 240 (class 1259 OID 24856)
-- Name: site_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.site_settings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    setting_key character varying(255) NOT NULL,
    setting_value text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.site_settings OWNER TO postgres;

--
-- TOC entry 241 (class 1259 OID 24863)
-- Name: user_2fa_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_2fa_settings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    is_enabled boolean DEFAULT false,
    secret_key character varying(255),
    backup_codes text[],
    last_used_at timestamp without time zone,
    enabled_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_2fa_settings OWNER TO postgres;

--
-- TOC entry 242 (class 1259 OID 24872)
-- Name: user_access_levels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_access_levels (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    email character varying(255) NOT NULL,
    has_professional_access boolean DEFAULT false,
    has_personal_access boolean DEFAULT false,
    granted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    granted_by uuid,
    is_active boolean DEFAULT true,
    notes text
);


ALTER TABLE public.user_access_levels OWNER TO postgres;

--
-- TOC entry 243 (class 1259 OID 24882)
-- Name: user_activity_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_activity_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    description text,
    performed_by character varying(255),
    ip_address character varying(45),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_activity_log OWNER TO postgres;

--
-- TOC entry 244 (class 1259 OID 24889)
-- Name: user_login_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_login_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    session_token character varying(255) NOT NULL,
    device_info text,
    ip_address inet,
    location character varying(255),
    is_current boolean DEFAULT false,
    last_activity timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_login_sessions OWNER TO postgres;

--
-- TOC entry 245 (class 1259 OID 24898)
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    permission_name character varying(100) NOT NULL,
    granted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    granted_by uuid,
    is_active boolean DEFAULT true
);


ALTER TABLE public.user_permissions OWNER TO postgres;

--
-- TOC entry 246 (class 1259 OID 24904)
-- Name: user_role_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_role_history (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    old_role character varying(100),
    new_role character varying(100) NOT NULL,
    changed_by uuid,
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    reason text
);


ALTER TABLE public.user_role_history OWNER TO postgres;

--
-- TOC entry 247 (class 1259 OID 24911)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying,
    email_verified boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone,
    login_attempts integer DEFAULT 0,
    locked_until timestamp without time zone,
    status character varying(50) DEFAULT 'active'::character varying,
    profile_image character varying(500),
    preferences jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY (ARRAY[('subscriber'::character varying)::text, ('author'::character varying)::text, ('editor'::character varying)::text, ('admin'::character varying)::text, ('user'::character varying)::text, ('moderator'::character varying)::text]))),
    CONSTRAINT users_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text, ('pending'::character varying)::text, ('suspended'::character varying)::text])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 248 (class 1259 OID 24926)
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verification_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    identifier character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    expires timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.verification_tokens OWNER TO postgres;

--
-- TOC entry 3445 (class 2604 OID 24933)
-- Name: media_folders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_folders ALTER COLUMN id SET DEFAULT nextval('public.media_folders_id_seq'::regclass);


--
-- TOC entry 3937 (class 0 OID 24589)
-- Dependencies: 215
-- Data for Name: access_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.access_requests (id, name, email, subject, message, request_type, requested_access_level, status, submitted_at, processed_at, processed_by, admin_notes) FROM stdin;
\.


--
-- TOC entry 3938 (class 0 OID 24601)
-- Dependencies: 216
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, user_id, type, provider, provider_account_id, refresh_token, access_token, expires_at, id_token, scope, session_state, token_type, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3939 (class 0 OID 24609)
-- Dependencies: 217
-- Data for Name: bulk_operations_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bulk_operations_log (id, operation_type, target_type, target_ids, parameters, status, total_items, processed_items, errors, performed_by, started_at, completed_at) FROM stdin;
\.


--
-- TOC entry 3940 (class 0 OID 24620)
-- Dependencies: 218
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, slug, description, color, post_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3941 (class 0 OID 24630)
-- Dependencies: 219
-- Data for Name: content_collaborators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.content_collaborators (id, content_id, content_type, user_id, user_email, permission_level, invited_by, invited_at, accepted_at, status) FROM stdin;
\.


--
-- TOC entry 3942 (class 0 OID 24640)
-- Dependencies: 220
-- Data for Name: content_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.content_comments (id, content_id, content_type, user_id, user_email, comment, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3943 (class 0 OID 24651)
-- Dependencies: 221
-- Data for Name: content_drafts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.content_drafts (id, content_type, content_id, title, content, metadata, created_by, created_at, updated_at, auto_save, version) FROM stdin;
74cfed01-dd6e-4655-9204-1be484e1e7e5	project	824d4f8d-3717-4485-9aee-93063d51978f	Sample Project Draft	This is a sample project draft for testing purposes.	{"tags": ["sample", "test"], "technologies": ["React", "TypeScript"]}	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 03:22:49.506793	2025-07-12 03:22:49.506793	f	1
03e7ca84-895e-4b26-9594-8ae4b2adb42a	post	66d1089c-4895-47a7-9155-ada1cb0bc1ca	Sample Blog Post Draft	This is a sample blog post draft for testing purposes.	{"tags": ["sample", "test"], "excerpt": "A sample blog post for testing."}	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 03:22:49.511345	2025-07-12 03:22:49.511345	f	1
\.


--
-- TOC entry 3944 (class 0 OID 24663)
-- Dependencies: 222
-- Data for Name: content_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.content_templates (id, name, type, description, content, variables, usage_count, author, created_at, updated_at) FROM stdin;
4aa6b778-32c5-4e0e-90a1-9cdf309705e9	Technical Blog Post	post	Template for technical blog posts with code examples	# {{title}}\\n\\n## Introduction\\n\\n{{introduction}}\\n\\n## Technical Implementation\\n\\n\\`\\`\\`{{language}}\\n{{code_example}}\\n\\`\\`\\`\\n\\n## Conclusion\\n\\n{{conclusion}}\\n\\n---\\n\\n*Published on {{publish_date}} | {{read_time}} min read*	\N	0	admin	2025-07-11 19:31:08.240523	2025-07-11 19:31:08.240523
0a5fb6fd-751c-4fd1-9fa6-7ae354bb590c	Project Showcase	project	Template for showcasing projects	# {{project_title}}\\n\\n## Overview\\n\\n{{project_overview}}\\n\\n## Key Features\\n\\n{{#features}}\\n- {{.}}\\n{{/features}}\\n\\n## Technologies\\n\\n{{technologies}}\\n\\n## Links\\n\\n- **Live Demo:** [{{project_title}}]({{live_url}})\\n- **GitHub:** [View Source]({{github_url}})	\N	0	admin	2025-07-11 19:31:13.058133	2025-07-11 19:31:13.058133
2826c65b-7c4d-48a7-af85-fb6b4f86cb3f	Web Application	project	Template for web app projects	# {{app_name}}\\n\\n## Project Summary\\n\\n{{app_description}}\\n\\n**Live Demo:** [{{app_name}}]({{live_url}})\\n**GitHub:** [View Source]({{github_url}})\\n\\n## Features\\n\\n{{#features}}\\n- ✅ {{.}}\\n{{/features}}\\n\\n## Tech Stack\\n\\n{{tech_stack}}\\n\\n---\\n\\n*Built with {{primary_tech}}*	\N	0	admin	2025-07-11 19:31:13.058133	2025-07-11 19:31:13.058133
\.


--
-- TOC entry 3945 (class 0 OID 24673)
-- Dependencies: 223
-- Data for Name: content_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.content_versions (id, content_id, content_type, version_number, title, content, changes_summary, created_by, created_at, is_current) FROM stdin;
\.


--
-- TOC entry 3946 (class 0 OID 24682)
-- Dependencies: 224
-- Data for Name: media_files; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media_files (id, filename, original_name, file_path, file_size, mime_type, content_type, alt_text, uploaded_by, created_at, starred, tags, folder, updated_at) FROM stdin;
0566d8f2-5343-4995-a494-85d5dd8685ac	d2e0d7ba-159a-4f23-b140-8c7eaee83bf4.jpg	Attachment.jpg	/uploads/general/d2e0d7ba-159a-4f23-b140-8c7eaee83bf4.jpg	19953	image/jpeg	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 15:44:22.274304	f	[]	\N	2025-07-12 05:37:28.639022
b68823e7-fc62-46a0-aab2-2bfff51e3244	ai-education-platform-1752285616679-picsumphotos-1.jpg	AI Education Platform Image	/uploads/project/ai-education-platform-1752285616679-picsumphotos-1.jpg	76996	image/jpeg	project	Image for AI Education Platform Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:00:23.283442	f	[]	\N	2025-07-12 05:37:28.639022
4e914172-8a12-4caa-b5b1-cee354a05d19	trump-rants-website-1752285624217-picsumphotos-1.jpg	Trump Rants Website Image	/uploads/project/trump-rants-website-1752285624217-picsumphotos-1.jpg	55331	image/jpeg	project	Image for Trump Rants Website Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:00:30.161424	f	[]	\N	2025-07-12 05:37:28.639022
1778de61-b069-4e14-871e-70fbafba8613	ai-voice-over-studio-1752285631558-picsumphotos-1.jpg	AI Voice-Over Studio Image	/uploads/project/ai-voice-over-studio-1752285631558-picsumphotos-1.jpg	76996	image/jpeg	project	Image for AI Voice-Over Studio Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:00:36.27466	f	[]	\N	2025-07-12 05:37:28.639022
9fb5f932-cd51-4c44-aae1-17dbaa508e3e	real-estate-business-platform-1752285638147-picsumphotos-1.jpg	Real Estate Business Platform Image	/uploads/project/real-estate-business-platform-1752285638147-picsumphotos-1.jpg	72432	image/jpeg	project	Image for Real Estate Business Platform Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:00:43.13514	f	[]	\N	2025-07-12 05:37:28.639022
86451795-998a-4037-b8c2-f4ce605676eb	rental-property-manager-1752285645537-picsumphotos-1.jpg	Rental Property Manager Image	/uploads/project/rental-property-manager-1752285645537-picsumphotos-1.jpg	147683	image/jpeg	project	Image for Rental Property Manager Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:00:50.244374	f	[]	\N	2025-07-12 05:37:28.639022
9ceb091c-5032-4f56-9a57-b1cdaf195e8d	digital-planner-creator-ecommerce-tool-1752285656114-picsumphotos-1.jpg	Digital Planner Creator - Ecommerce Tool Image	/uploads/project/digital-planner-creator-ecommerce-tool-1752285656114-picsumphotos-1.jpg	159979	image/jpeg	project	Image for Digital Planner Creator - Ecommerce Tool Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:01:02.571604	f	[]	\N	2025-07-12 05:37:28.639022
fbebbda9-445e-46d0-9146-d4b63e59eb19	vinyl-graphics-ecommerce-platform-1752285663950-picsumphotos-1.jpg	Vinyl Graphics Ecommerce Platform Image	/uploads/project/vinyl-graphics-ecommerce-platform-1752285663950-picsumphotos-1.jpg	112616	image/jpeg	project	Image for Vinyl Graphics Ecommerce Platform Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:01:09.504263	f	[]	\N	2025-07-12 05:37:28.639022
859e71b3-d214-4e86-b587-aff966a3ab72	grocery-management-app-1752285671525-picsumphotos-1.jpg	Grocery Management App Image	/uploads/project/grocery-management-app-1752285671525-picsumphotos-1.jpg	85125	image/jpeg	project	Image for Grocery Management App Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:01:16.527946	f	[]	\N	2025-07-12 05:37:28.639022
77f5a435-7239-4f90-b70e-cdd1a51f8801	unique-story-game-1752285679002-picsumphotos-1.jpg	Unique Story Game Image	/uploads/project/unique-story-game-1752285679002-picsumphotos-1.jpg	109560	image/jpeg	project	Image for Unique Story Game Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:01:25.752803	f	[]	\N	2025-07-12 05:37:28.639022
152f1ef0-e535-403c-a292-0ba2292890db	t-shirt-2-0-1752285686545-picsumphotos-1.jpg	T-Shirt 2.0 Image	/uploads/project/t-shirt-2-0-1752285686545-picsumphotos-1.jpg	106135	image/jpeg	project	Image for T-Shirt 2.0 Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:01:32.825422	f	[]	\N	2025-07-12 05:37:28.639022
7c4edd44-ba23-4d8a-8bf5-25a353823f6d	syll-syllabus-management-system-1752285697062-picsumphotos-1.jpg	Syll - Syllabus Management System Image	/uploads/project/syll-syllabus-management-system-1752285697062-picsumphotos-1.jpg	101451	image/jpeg	project	Image for Syll - Syllabus Management System Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:01:42.796584	f	[]	\N	2025-07-12 05:37:28.639022
303a2948-89e7-4d4c-be78-b65504632107	social-media-uploader-1752285704860-picsumphotos-1.jpg	Social Media Uploader Image	/uploads/project/social-media-uploader-1752285704860-picsumphotos-1.jpg	117383	image/jpeg	project	Image for Social Media Uploader Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:01:49.861459	f	[]	\N	2025-07-12 05:37:28.639022
a4fea46a-79b7-4c5a-87a9-36400517b5a5	roku-midas-touch-1752285712376-picsumphotos-1.jpg	Roku Midas Touch Image	/uploads/project/roku-midas-touch-1752285712376-picsumphotos-1.jpg	82333	image/jpeg	project	Image for Roku Midas Touch Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:01:58.618342	f	[]	\N	2025-07-12 05:37:28.639022
42e5e78a-16a9-4a17-8e13-ac9cf1722eab	rate-my-rack-1752285719451-picsumphotos-1.jpg	Rate My Rack Image	/uploads/project/rate-my-rack-1752285719451-picsumphotos-1.jpg	82333	image/jpeg	project	Image for Rate My Rack Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:02:04.810505	f	[]	\N	2025-07-12 05:37:28.639022
4fb74966-efe9-4ee3-b453-7cc1761288ed	prpg-game-app-1752285726068-picsumphotos-1.jpg	PRPG Game App Image	/uploads/project/prpg-game-app-1752285726068-picsumphotos-1.jpg	89760	image/jpeg	project	Image for PRPG Game App Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:02:11.82045	f	[]	\N	2025-07-12 05:37:28.639022
792e6454-ebb3-43a7-9202-64f55a4cfddd	price-scraper-test-1752285736570-picsumphotos-1.jpg	Price Scraper Test Image	/uploads/project/price-scraper-test-1752285736570-picsumphotos-1.jpg	107974	image/jpeg	project	Image for Price Scraper Test Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:02:21.927473	f	[]	\N	2025-07-12 05:37:28.639022
c3087386-d28c-4bd9-9c52-246b4dd36bd9	group-chat-international-1752285744415-picsumphotos-1.jpg	Group Chat International Image	/uploads/project/group-chat-international-1752285744415-picsumphotos-1.jpg	189115	image/jpeg	project	Image for Group Chat International Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:02:31.103383	f	[]	\N	2025-07-12 05:37:28.639022
16e8d5d2-2c63-4d4f-9ac4-87521b91438f	ecommerce-app-dropship-murphy-1752285751971-picsumphotos-1.jpg	Ecommerce App Dropship Murphy Image	/uploads/project/ecommerce-app-dropship-murphy-1752285751971-picsumphotos-1.jpg	88048	image/jpeg	project	Image for Ecommerce App Dropship Murphy Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:02:38.020288	f	[]	\N	2025-07-12 05:37:28.639022
1b3e145d-e2f1-4da1-afe0-cf08cdacfc71	copy-tool-content-duplication-assistant-1752285759362-picsumphotos-1.jpg	Copy Tool - Content Duplication Assistant Image	/uploads/project/copy-tool-content-duplication-assistant-1752285759362-picsumphotos-1.jpg	159979	image/jpeg	project	Image for Copy Tool - Content Duplication Assistant Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:02:44.146412	f	[]	\N	2025-07-12 05:37:28.639022
069dca7c-659a-400d-b986-c16707e7c88b	brand-builder-ai-v2-1752285765955-picsumphotos-1.jpg	Brand Builder AI v2 Image	/uploads/project/brand-builder-ai-v2-1752285765955-picsumphotos-1.jpg	76996	image/jpeg	project	Image for Brand Builder AI v2 Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:02:50.256873	f	[]	\N	2025-07-12 05:37:28.639022
e6573410-e70e-4347-acd7-c467473c33ef	family-dinner-recommendation-app-1752285775527-picsumphotos-1.jpg	Family Dinner Recommendation App Image	/uploads/project/family-dinner-recommendation-app-1752285775527-picsumphotos-1.jpg	85125	image/jpeg	project	Image for Family Dinner Recommendation App Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:03:00.064575	f	[]	\N	2025-07-12 05:37:28.639022
9e9cb2f9-1854-4bf5-9062-a0228c3232af	sports-analytics-desktop-1752285782079-picsumphotos-1.jpg	Sports Analytics Desktop Image	/uploads/project/sports-analytics-desktop-1752285782079-picsumphotos-1.jpg	86522	image/jpeg	project	Image for Sports Analytics Desktop Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:03:08.270128	f	[]	\N	2025-07-12 05:37:28.639022
bce3e87b-5a32-4f2e-b835-12de2f5eb685	squirrel-commander-mobile-game-1752285789439-picsumphotos-1.jpg	Squirrel Commander Mobile Game Image	/uploads/project/squirrel-commander-mobile-game-1752285789439-picsumphotos-1.jpg	109560	image/jpeg	project	Image for Squirrel Commander Mobile Game Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:03:14.341268	f	[]	\N	2025-07-12 05:37:28.639022
c97c3039-542f-4117-b927-d95a9aeb1d56	223b3533-6974-4645-814d-12fcdbf3fe2d.jpg	image.jpg	/uploads/project/223b3533-6974-4645-814d-12fcdbf3fe2d.jpg	42623	image/jpeg	project	Resized image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-23 22:43:41.126142	f	[]	\N	2025-10-23 22:43:41.126142
d04277ca-2952-420f-9f25-c3d4e05ec3a0	project-database-dashboard-1752285796052-picsumphotos-1.jpg	Project Database Dashboard Image	/uploads/project/project-database-dashboard-1752285796052-picsumphotos-1.jpg	141699	image/jpeg	project	Image for Project Database Dashboard Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:03:21.364482	f	[]	\N	2025-07-12 05:37:28.639022
3fd4d867-f2cf-455d-be58-98894b12612d	netops-wan-monitoring-tool-1752285803608-picsumphotos-1.jpg	NetOps WAN Monitoring Tool Image	/uploads/project/netops-wan-monitoring-tool-1752285803608-picsumphotos-1.jpg	82333	image/jpeg	project	Image for NetOps WAN Monitoring Tool Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:03:27.55234	f	[]	\N	2025-07-12 05:37:28.639022
dacd32c8-ff83-47bc-abfb-5be6cfdd9ea4	darklands-modern-classic-rpg-modernization-1752285813494-picsumphotos-1.jpg	Darklands Modern - Classic RPG Modernization Image	/uploads/project/darklands-modern-classic-rpg-modernization-1752285813494-picsumphotos-1.jpg	89760	image/jpeg	project	Image for Darklands Modern - Classic RPG Modernization Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:03:39.131169	f	[]	\N	2025-07-12 05:37:28.639022
40815808-505d-4da7-a4bb-47315a2db5ba	habit-builder-intelligent-habit-tracking-app-1752285820230-picsumphotos-1.jpg	Habit Builder - Intelligent Habit Tracking App Image	/uploads/project/habit-builder-intelligent-habit-tracking-app-1752285820230-picsumphotos-1.jpg	141699	image/jpeg	project	Image for Habit Builder - Intelligent Habit Tracking App Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:03:45.334682	f	[]	\N	2025-07-12 05:37:28.639022
d256b6de-5b4a-4eb6-8182-2d74b628e62b	ai-date-night-social-media-profile-analysis-1752285826870-picsumphotos-1.jpg	AI Date Night - Social Media Profile Analysis Image	/uploads/project/ai-date-night-social-media-profile-analysis-1752285826870-picsumphotos-1.jpg	117383	image/jpeg	project	Image for AI Date Night - Social Media Profile Analysis Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:03:51.371407	f	[]	\N	2025-07-12 05:37:28.639022
36263ec3-328e-47e3-be8c-c39784e6eec9	posti-bot-desktop-multi-bot-creation-tool-1752285833449-picsumphotos-1.jpg	Posti-Bot - Desktop Multi-Bot Creation Tool Image	/uploads/project/posti-bot-desktop-multi-bot-creation-tool-1752285833449-picsumphotos-1.jpg	76996	image/jpeg	project	Image for Posti-Bot - Desktop Multi-Bot Creation Tool Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:03:57.55647	f	[]	\N	2025-07-12 05:37:28.639022
5264f07f-b303-4734-be8f-f0e9b84be552	ai-education-platform-comprehensive-learning-hub-1752285840032-picsumphotos-1.jpg	AI Education Platform - Comprehensive Learning Hub Image	/uploads/project/ai-education-platform-comprehensive-learning-hub-1752285840032-picsumphotos-1.jpg	101451	image/jpeg	project	Image for AI Education Platform - Comprehensive Learning Hub Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:04:05.855857	f	[]	\N	2025-07-12 05:37:28.639022
15989a1f-5e59-4ad3-94d1-48fe0daa80b5	test-project-1752275001210-1752285849619-picsumphotos-1.jpg	Test Project - 2025-07-11T23:03:21.210Z Image	/uploads/project/test-project-1752275001210-1752285849619-picsumphotos-1.jpg	141699	image/jpeg	project	Image for Test Project - 2025-07-11T23:03:21.210Z Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:04:14.869626	f	[]	\N	2025-07-12 05:37:28.639022
cbdcde20-6775-4d5d-b3eb-92faff94419a	ai-image-generator-1752285856226-picsumphotos-1.jpg	AI Image Generator Image	/uploads/project/ai-image-generator-1752285856226-picsumphotos-1.jpg	76996	image/jpeg	project	Image for AI Image Generator Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:04:20.972211	f	[]	\N	2025-07-12 05:37:28.639022
269ec361-54ee-41cc-8da8-c2b0aaf33a82	task-management-dashboard-1752285862765-picsumphotos-1.jpg	Task Management Dashboard Image	/uploads/project/task-management-dashboard-1752285862765-picsumphotos-1.jpg	141699	image/jpeg	project	Image for Task Management Dashboard Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:04:27.092342	f	[]	\N	2025-07-12 05:37:28.639022
60d29f10-2b9c-4693-b4ad-a6cdfd964f13	weather-dashboard-1752285869350-picsumphotos-1.jpg	Weather Dashboard Image	/uploads/project/weather-dashboard-1752285869350-picsumphotos-1.jpg	142183	image/jpeg	project	Image for Weather Dashboard Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:04:34.159301	f	[]	\N	2025-07-12 05:37:28.639022
c34f57dd-c7dd-408f-a5eb-6a56f3323bf7	ecommerce-platform-1752285876894-picsumphotos-1.jpg	E-commerce Platform Image	/uploads/project/ecommerce-platform-1752285876894-picsumphotos-1.jpg	141699	image/jpeg	project	Image for E-commerce Platform Image	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 02:04:42.456749	f	[]	\N	2025-07-12 05:37:28.639022
8132a307-1c78-4dcf-9e5b-33b46da55b1d	107aec23-0d49-46fc-92cb-542f61124a08.png	candlestick_chart.png	/uploads/general/107aec23-0d49-46fc-92cb-542f61124a08.png	7961	image/png	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 05:19:38.109134	f	[]	\N	2025-07-12 05:37:28.639022
c8fddec0-0f2a-43cb-a03c-3a4f0f5667f9	779116e9-b60c-4828-a729-4d2361280aa1.png	Problem Solver.png	/uploads/general/779116e9-b60c-4828-a729-4d2361280aa1.png	3816	image/png	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 06:24:35.937683	f	[]	\N	2025-07-12 06:24:35.937683
44212c21-c53c-4037-a581-9a90d2df597b	branding-a0bbe598-5c50-4377-a2c5-a3a67d06959b.png	jlk-logo.png	/uploads/general/branding-a0bbe598-5c50-4377-a2c5-a3a67d06959b.png	301782	image/png	general	Website Logo	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 14:21:58.143361	f	[]	\N	2025-07-12 14:21:58.143361
8bd9fbc8-9141-46f3-8240-4a812224f4bd	branding-78444cbb-7694-4687-a9a9-3ea7035feed2.svg	jlk-logo.svg	/uploads/general/branding-78444cbb-7694-4687-a9a9-3ea7035feed2.svg	129981	image/svg+xml	general	Website Logo (SVG)	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 14:21:58.174598	f	[]	\N	2025-07-12 14:21:58.174598
7cc417a5-411b-4ae9-a321-2e09cb440f2b	profile-0c60b0ee-5534-458e-afc2-98ba95e9b6b3.jpg	9197d18e-f756-4777-8122-62a73db8ff89.jpg	/uploads/general/profile-0c60b0ee-5534-458e-afc2-98ba95e9b6b3.jpg	19953	image/jpeg	general	Profile photo	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 14:21:58.313975	f	[]	\N	2025-07-12 14:21:58.313975
947cbb54-c81d-4d55-aab7-490b55b2eeff	profile-16381277-e08d-47cf-8ee5-873c90099131.jpg	7245626d-1e82-4e58-807c-d02b0720260a.jpg	/uploads/general/profile-16381277-e08d-47cf-8ee5-873c90099131.jpg	19953	image/jpeg	general	Profile photo	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 14:21:58.333393	f	[]	\N	2025-07-12 14:21:58.333393
36f25726-b149-4dc3-b014-0c12a464e669	slideshow-aae39b47-dd5c-4dda-a6b8-f4c98a8851bc.jpg	coding-1.jpg	/images/slideshow/slideshow-aae39b47-dd5c-4dda-a6b8-f4c98a8851bc.jpg	119104	image/jpeg	general	Background slideshow image - coding workspace	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 14:21:58.204597	f	[]	\N	2025-07-12 14:21:58.204597
93195acb-4558-4d07-b73c-fd492f15d3f8	coding-workspace-1.jpg	coding-2.jpg	/images/slideshow/coding-workspace-1.jpg	119104	image/jpeg	general	Modern coding workspace with laptop and multiple monitors slideshow	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 14:21:58.226947	f	[]	\N	2025-10-23 19:58:12.234105
875f1a68-5fcf-4d75-855a-2181ec5fc71a	programming-setup-2.jpg	coding-3.jpg	/images/slideshow/programming-setup-2.jpg	119104	image/jpeg	general	Programming environment with code on screen slideshow	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 14:21:58.250294	f	[]	\N	2025-10-23 19:58:12.244131
adc7ba07-ba80-4469-b73d-42a6bf88842f	web-development-3.jpg	coding-4.jpg	/images/slideshow/web-development-3.jpg	119104	image/jpeg	general	Web development workspace with modern tools slideshow	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 14:21:58.272796	f	[]	\N	2025-10-23 19:58:12.249478
f832b8a4-94c6-487c-b59a-e6603b608cad	tech-workspace-4.jpg	coding-5.jpg	/images/slideshow/tech-workspace-4.jpg	119104	image/jpeg	general	Technology workspace with development setup slideshow	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-12 14:21:58.294016	f	[]	\N	2025-10-23 19:58:12.254458
4b8c3a48-c6db-4cae-b6d9-a24b2b665efb	ca631513-8552-4bfe-8508-c46a1fdd47ee.png	ai-date-night-cover-art-2-2025-10-23-20-35-00.png	/uploads/general/ca631513-8552-4bfe-8508-c46a1fdd47ee.png	902894	image/png	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-23 20:36:27.329641	f	[]	\N	2025-10-23 20:36:27.329641
963bb283-521c-45a1-a292-7652fd0fd9ce	e72e6330-f77d-42eb-855e-ef211a19e1b4.png	squirrel-mobile-game-cover-art-4-2025-10-23-20-47-39.png	/uploads/general/e72e6330-f77d-42eb-855e-ef211a19e1b4.png	1849771	image/png	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-23 20:51:40.400783	f	[]	\N	2025-10-23 20:51:40.400783
020c4a90-b05c-44f7-9940-bba04ad19859	1cba08a1-2dec-4efd-b2aa-e8deb771517f.png	custom-image-cover-art-2-2025-10-24-17-07-22.png	/uploads/general/1cba08a1-2dec-4efd-b2aa-e8deb771517f.png	2182731	image/png	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:08:21.327265	f	[]	\N	2025-10-24 17:08:21.327265
1143daab-837f-47a7-9b35-542747eda8f7	20c06eaf-5e0a-4c39-88e9-059afe73b3f3.jpg	b-ZuLHicu5meUVJSUGylr5-al1xUWVCSmqJbkpRnoJdeXJJYkpmsl5yfq5-Zm5ieWmxfaAuUsXL0S7F0Tw7M8ioMj8zLT87OS67UDc1yjPTLT8vVdTEx8k51riiNKogoqwjNyQjwcXIMVCu2NTQAACcFJbM.jpg	/uploads/general/20c06eaf-5e0a-4c39-88e9-059afe73b3f3.jpg	28841	image/jpeg	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:18:55.635154	f	[]	\N	2025-10-24 17:18:55.635154
5931362b-019e-4aa9-b350-463955053537	e2fc145c-0b26-41c1-ad78-1571c6bc620c.jpg	v2-t4jpr-vnhxp.jpg	/uploads/general/e2fc145c-0b26-41c1-ad78-1571c6bc620c.jpg	126046	image/jpeg	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:19:03.975836	f	[]	\N	2025-10-24 17:19:03.975836
e73c5b7d-5d63-425a-a541-48a4d7e70a80	896d63ee-e4c4-4754-a680-e7ee3e22fac4.jpg	epe.brightspotcdn.jpg	/uploads/general/896d63ee-e4c4-4754-a680-e7ee3e22fac4.jpg	41436	image/jpeg	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:19:10.468922	f	[]	\N	2025-10-24 17:19:10.468922
cf2663e3-d3c8-401f-b105-9a5d51c499de	d159617e-b65c-4894-98a7-83bb33fd0742.png	a7a13be5-2145-4d43-8b02-9493915629bd-cover.png	/uploads/general/d159617e-b65c-4894-98a7-83bb33fd0742.png	436848	image/png	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:19:26.194595	f	[]	\N	2025-10-24 17:19:26.194595
6e5f1b4c-2446-4547-924a-df5a1926d676	0a7c3cb7-a0a3-40fd-bd41-19028817989f.png	800966cc-495a-4d7f-8afe-e5f2a3e89456-cover.png	/uploads/general/0a7c3cb7-a0a3-40fd-bd41-19028817989f.png	265441	image/png	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:19:30.608053	f	[]	\N	2025-10-24 17:19:30.608053
f3f6b684-7b3b-4b52-8c1d-757be4878b8e	bcba2e97-4212-49ab-8b2d-7a260c48b1fc.jpg	bigstock-Mature-indian-man-shaking-hand-425269622.jpg	/uploads/general/bcba2e97-4212-49ab-8b2d-7a260c48b1fc.jpg	292249	image/jpeg	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:19:52.423746	f	[]	\N	2025-10-24 17:19:52.423746
3aa975c0-7259-48ef-9fff-5ead765bed4c	56817629-3a18-4b0f-806f-95a17df77830.webp	ryan-barone-diylandlord.webp	/uploads/general/56817629-3a18-4b0f-806f-95a17df77830.webp	70426	image/webp	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:19:56.812191	f	[]	\N	2025-10-24 17:19:56.812191
9dff2eee-a326-4c89-9327-83fd17ed18d7	9b3bf03e-d6e4-46cf-b2e7-68a5a4a9f95d.jpg	real_estate_management_system_overview_dashboard_slide01.jpg	/uploads/general/9b3bf03e-d6e4-46cf-b2e7-68a5a4a9f95d.jpg	88956	image/jpeg	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:19:59.866914	f	[]	\N	2025-10-24 17:19:59.866914
8240cca8-30a9-47a3-a7c5-bd007332261b	a3738b1c-4e32-42c4-8de3-f6b9bc447307.jpg	01_top-platforms-t-shirts-online.jpg	/uploads/general/a3738b1c-4e32-42c4-8de3-f6b9bc447307.jpg	117159	image/jpeg	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:20:10.412988	f	[]	\N	2025-10-24 17:20:10.412988
fb32320b-5638-4c1d-a6ba-e7623dbaabe3	7c5c0281-ca23-419d-85cb-c31f608137fc.jpg	Unisex-Jersey-Short-Sleeve-Tee-with-design.jpg	/uploads/general/7c5c0281-ca23-419d-85cb-c31f608137fc.jpg	56714	image/jpeg	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:20:14.774991	f	[]	\N	2025-10-24 17:20:14.774991
882281d0-363d-42fb-884f-8ff5975959fb	2eeddc92-6868-4507-a51b-4a78de8a1c52.jpg	129793724-jet-engine-of-airplane-in-outline-style-industrial-aerospace-blueprint-drawing-of-plane-motor.jpg	/uploads/general/2eeddc92-6868-4507-a51b-4a78de8a1c52.jpg	136756	image/jpeg	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:20:42.152097	f	[]	\N	2025-10-24 17:20:42.152097
75b471fb-3862-4559-b9a1-ff1de659e557	3ead20ff-98fb-40ec-91e7-6f6b799772ed.png	daily-habit-tracker.png	/uploads/general/3ead20ff-98fb-40ec-91e7-6f6b799772ed.png	31686	image/png	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:20:59.792416	f	[]	\N	2025-10-24 17:20:59.792416
93bcb46e-97b5-4b0c-9e96-0ce9a2128d54	46634db3-e8fa-4ac9-91dd-4701cc0b54cf.jpg	17898609-global-communication-icon.jpg	/uploads/general/46634db3-e8fa-4ac9-91dd-4701cc0b54cf.jpg	121693	image/jpeg	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:21:10.358417	f	[]	\N	2025-10-24 17:21:10.358417
710a4e75-8bc2-4287-bc33-97c24f7cf84a	bf2ae2a2-e5bc-491e-a52c-751548c75b23.jpg	73527302-concept-of-social-network-people-connecting-across-the-world-and-chat-through-mobile-laptops.jpg	/uploads/general/bf2ae2a2-e5bc-491e-a52c-751548c75b23.jpg	116791	image/jpeg	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:21:14.779279	f	[]	\N	2025-10-24 17:21:14.779279
66911a3b-f2be-4dbb-adbe-242f1e9d6711	0c3abfbc-ad8a-43c8-9f04-036e0a385571.webp	depositphotos_272881628-stock-photo-carton-boxes-with-dropshipping-text.webp	/uploads/general/0c3abfbc-ad8a-43c8-9f04-036e0a385571.webp	21190	image/webp	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:21:22.867652	f	[]	\N	2025-10-24 17:21:22.867652
54542c42-5b3b-4273-99dd-02af0553d05b	8bdea1d9-7608-4d5b-951f-a9444e8ce48b.gif	Screenshot 2025-10-24 123202.gif	/uploads/general/8bdea1d9-7608-4d5b-951f-a9444e8ce48b.gif	1222945	image/gif	general	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-10-24 17:32:35.291709	f	[]	\N	2025-10-24 17:32:35.291709
\.


--
-- TOC entry 3947 (class 0 OID 24694)
-- Dependencies: 225
-- Data for Name: media_folders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media_folders (id, name, parent_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3949 (class 0 OID 24700)
-- Dependencies: 227
-- Data for Name: newsletter_analytics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.newsletter_analytics (id, campaign_id, subscriber_id, email, event_type, event_data, user_agent, ip_address, created_at) FROM stdin;
\.


--
-- TOC entry 3950 (class 0 OID 24709)
-- Dependencies: 228
-- Data for Name: newsletter_automation_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.newsletter_automation_rules (id, name, description, type, is_active, trigger_conditions, template_id, schedule_config, target_criteria, last_run_at, next_run_at, created_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3951 (class 0 OID 24721)
-- Dependencies: 229
-- Data for Name: newsletter_campaigns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.newsletter_campaigns (id, title, slug, subject, preview_text, content, html_content, plain_text_content, template_id, status, type, permissions, target_access_levels, scheduled_send_at, sent_at, recipient_count, author, created_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3952 (class 0 OID 24736)
-- Dependencies: 230
-- Data for Name: newsletter_content; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.newsletter_content (id, title, description, incentive, subscriber_count, footer_text, weekly_articles_icon, weekly_articles_title, weekly_articles_description, exclusive_tips_icon, exclusive_tips_title, exclusive_tips_description, early_access_icon, early_access_title, early_access_description, created_at, updated_at) FROM stdin;
c02a982b-be4d-4189-9d2d-8f444bad974b	Stay in the Loop	Get notified about new projects, blog posts, and insights on my latest learnings.	Also get access to more content.	1	By subscribing, you agree to receive our newsletter and promotional emails.	document	Weekly Articles	Hear about what I am learning now	bolt	More to See	Subscriber-only content and resources	clock	Early Access	Be first to see new projects and posts	2025-07-09 18:32:23.264372	2025-07-10 17:49:07.096851
\.


--
-- TOC entry 3953 (class 0 OID 24754)
-- Dependencies: 231
-- Data for Name: newsletter_subscribers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.newsletter_subscribers (id, email, name, first_name, last_name, phone, company, interests, subscription_source, subscription_date, is_active, is_confirmed, unsubscribe_token, unsubscribed_at, unsubscribe_reason, preferences, metadata, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3954 (class 0 OID 24769)
-- Dependencies: 232
-- Data for Name: newsletter_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.newsletter_templates (id, name, description, template_html, template_variables, is_default, usage_count, created_by, created_at, updated_at, type, html_content, plain_text_content, subject_template, preview_text_template, variables, is_active, is_system) FROM stdin;
be16322e-f944-459e-b0b2-205eb9112bc0	Default Newsletter	Default newsletter template with header, content, and footer	<!DOCTYPE html><html><head><title>{{title}}</title></head><body><div class="container"><header><h1>{{header_title}}</h1></header><main>{{content}}</main><footer><p>{{footer_text}}</p></footer></div></body></html>	{title,header_title,content,footer_text}	t	0	\N	2025-07-09 17:19:49.316524	2025-07-11 19:15:46.674485	custom	<!DOCTYPE html><html><head><title>{{title}}</title></head><body><div class="container"><header><h1>{{header_title}}</h1></header><main>{{content}}</main><footer><p>{{footer_text}}</p></footer></div></body></html>	\N	Default Newsletter	\N	["title", "header_title", "content", "footer_text"]	t	t
a90051c0-281d-44ca-8687-9c7848362cbd	Monthly Digest	Automated monthly newsletter with recent posts and projects	<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r\n    <title>{{subject}}</title>\r\n</head>\r\n<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">\r\n    <div style="background: #f8f9fa; padding: 30px; border-radius: 10px; margin-bottom: 20px;">\r\n        <h1 style="color: #2563eb; margin: 0 0 10px 0;">{{newsletter_title}}</h1>\r\n        <p style="color: #666; margin: 0;">{{month}} {{year}} Edition</p>\r\n    </div>\r\n    \r\n    <div style="margin-bottom: 30px;">\r\n        <h2 style="color: #1f2937; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px;">Recent Blog Posts</h2>\r\n        {{#recent_posts}}\r\n        <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; margin-bottom: 15px;">\r\n            <h3 style="margin: 0 0 10px 0;"><a href="{{url}}" style="color: #2563eb; text-decoration: none;">{{title}}</a></h3>\r\n            <p style="color: #666; margin: 0 0 10px 0;">{{excerpt}}</p>\r\n            <div style="color: #888; font-size: 14px;">{{date}} • {{read_time}} min read</div>\r\n        </div>\r\n        {{/recent_posts}}\r\n    </div>\r\n    \r\n    <div style="margin-bottom: 30px;">\r\n        <h2 style="color: #1f2937; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px;">Featured Projects</h2>\r\n        {{#recent_projects}}\r\n        <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; margin-bottom: 15px;">\r\n            <h3 style="margin: 0 0 10px 0;"><a href="{{url}}" style="color: #2563eb; text-decoration: none;">{{title}}</a></h3>\r\n            <p style="color: #666; margin: 0 0 10px 0;">{{description}}</p>\r\n            <div style="color: #888; font-size: 14px;">Technologies: {{technologies}}</div>\r\n        </div>\r\n        {{/recent_projects}}\r\n    </div>\r\n    \r\n    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center; margin-top: 30px;">\r\n        <p style="color: #666; margin: 0;">Thanks for reading! Forward this to a friend or <a href="{{share_url}}" style="color: #2563eb;">share on social media</a>.</p>\r\n    </div>\r\n</body>\r\n</html>	{newsletter_title,month,year,recent_posts,recent_projects,share_url}	t	0	\N	2025-07-11 19:18:27.601187	2025-07-11 19:18:27.601187	custom	<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r\n    <title>{{subject}}</title>\r\n</head>\r\n<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">\r\n    <div style="background: #f8f9fa; padding: 30px; border-radius: 10px; margin-bottom: 20px;">\r\n        <h1 style="color: #2563eb; margin: 0 0 10px 0;">{{newsletter_title}}</h1>\r\n        <p style="color: #666; margin: 0;">{{month}} {{year}} Edition</p>\r\n    </div>\r\n    \r\n    <div style="margin-bottom: 30px;">\r\n        <h2 style="color: #1f2937; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px;">Recent Blog Posts</h2>\r\n        {{#recent_posts}}\r\n        <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; margin-bottom: 15px;">\r\n            <h3 style="margin: 0 0 10px 0;"><a href="{{url}}" style="color: #2563eb; text-decoration: none;">{{title}}</a></h3>\r\n            <p style="color: #666; margin: 0 0 10px 0;">{{excerpt}}</p>\r\n            <div style="color: #888; font-size: 14px;">{{date}} • {{read_time}} min read</div>\r\n        </div>\r\n        {{/recent_posts}}\r\n    </div>\r\n    \r\n    <div style="margin-bottom: 30px;">\r\n        <h2 style="color: #1f2937; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px;">Featured Projects</h2>\r\n        {{#recent_projects}}\r\n        <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; margin-bottom: 15px;">\r\n            <h3 style="margin: 0 0 10px 0;"><a href="{{url}}" style="color: #2563eb; text-decoration: none;">{{title}}</a></h3>\r\n            <p style="color: #666; margin: 0 0 10px 0;">{{description}}</p>\r\n            <div style="color: #888; font-size: 14px;">Technologies: {{technologies}}</div>\r\n        </div>\r\n        {{/recent_projects}}\r\n    </div>\r\n    \r\n    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center; margin-top: 30px;">\r\n        <p style="color: #666; margin: 0;">Thanks for reading! Forward this to a friend or <a href="{{share_url}}" style="color: #2563eb;">share on social media</a>.</p>\r\n    </div>\r\n</body>\r\n</html>	Monthly Newsletter - {{month}} {{year}}\r\n\r\nRecent Blog Posts:\r\n{{#recent_posts}}\r\n• {{title}} - {{url}}\r\n  {{excerpt}}\r\n  {{date}} • {{read_time}} min read\r\n\r\n{{/recent_posts}}\r\n\r\nFeatured Projects:\r\n{{#recent_projects}}\r\n• {{title}} - {{url}}\r\n  {{description}}\r\n  Technologies: {{technologies}}\r\n\r\n{{/recent_projects}}\r\n\r\nThanks for reading!	{{newsletter_title}} - {{month}} {{year}} Edition	\N	{"year": "Year", "month": "Month", "share_url": "", "recent_posts": [], "recent_projects": [], "newsletter_title": "Monthly Newsletter"}	t	f
c678c7ac-7ca4-4934-90ec-6c2c76c340c1	Project Showcase	Highlight your latest projects and work	<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r\n    <title>{{subject}}</title>\r\n</head>\r\n<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">\r\n    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px; border-radius: 10px; margin-bottom: 30px; text-align: center;">\r\n        <h1 style="margin: 0 0 10px 0; font-size: 28px;">{{project_title}}</h1>\r\n        <p style="margin: 0; opacity: 0.9; font-size: 18px;">{{project_subtitle}}</p>\r\n    </div>\r\n    \r\n    <div style="margin-bottom: 30px;">\r\n        <img src="{{project_image}}" alt="{{project_title}}" style="width: 100%; border-radius: 8px; margin-bottom: 20px;">\r\n        <h2 style="color: #1f2937; margin: 0 0 15px 0;">Project Overview</h2>\r\n        <p style="color: #555; line-height: 1.8;">{{project_description}}</p>\r\n    </div>\r\n    \r\n    <div style="text-align: center; margin-top: 40px;">\r\n        <a href="{{project_url}}" style="background: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: 500;">View Project</a>\r\n        <a href="{{github_url}}" style="background: #374151; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: 500; margin-left: 15px;">View Code</a>\r\n    </div>\r\n</body>\r\n</html>	{project_title,project_subtitle,project_description,project_image,project_url,github_url}	f	0	\N	2025-07-11 19:18:27.601187	2025-07-11 19:18:27.601187	custom	<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r\n    <title>{{subject}}</title>\r\n</head>\r\n<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">\r\n    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px; border-radius: 10px; margin-bottom: 30px; text-align: center;">\r\n        <h1 style="margin: 0 0 10px 0; font-size: 28px;">{{project_title}}</h1>\r\n        <p style="margin: 0; opacity: 0.9; font-size: 18px;">{{project_subtitle}}</p>\r\n    </div>\r\n    \r\n    <div style="margin-bottom: 30px;">\r\n        <img src="{{project_image}}" alt="{{project_title}}" style="width: 100%; border-radius: 8px; margin-bottom: 20px;">\r\n        <h2 style="color: #1f2937; margin: 0 0 15px 0;">Project Overview</h2>\r\n        <p style="color: #555; line-height: 1.8;">{{project_description}}</p>\r\n    </div>\r\n    \r\n    <div style="text-align: center; margin-top: 40px;">\r\n        <a href="{{project_url}}" style="background: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: 500;">View Project</a>\r\n        <a href="{{github_url}}" style="background: #374151; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: 500; margin-left: 15px;">View Code</a>\r\n    </div>\r\n</body>\r\n</html>	Project Showcase: {{project_title}}\r\n\r\n{{project_description}}\r\n\r\nView Project: {{project_url}}\r\nView Code: {{github_url}}	New Project: {{project_title}}	\N	{"github_url": "", "project_url": "", "project_image": "", "project_title": "Project Name", "project_subtitle": "Brief description", "project_description": "Detailed description"}	t	f
6ab49215-0b97-4fba-af53-3fdc3faeacf0	Blog Highlights	Curated selection of your best blog posts	<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r\n    <title>{{subject}}</title>\r\n</head>\r\n<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">\r\n    <div style="text-align: center; margin-bottom: 40px;">\r\n        <h1 style="color: #1f2937; margin: 0 0 10px 0;">{{newsletter_title}}</h1>\r\n        <p style="color: #666; margin: 0;">{{subtitle}}</p>\r\n    </div>\r\n    \r\n    <div style="margin-bottom: 30px;">\r\n        <h2 style="color: #dc2626; border-bottom: 2px solid #fecaca; padding-bottom: 10px;">Featured Article</h2>\r\n        <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 25px; margin-bottom: 20px;">\r\n            <h3 style="margin: 0 0 15px 0;"><a href="{{featured_url}}" style="color: #dc2626; text-decoration: none;">{{featured_title}}</a></h3>\r\n            <p style="color: #666; margin: 0 0 15px 0; font-style: italic;">{{featured_excerpt}}</p>\r\n            <a href="{{featured_url}}" style="background: #dc2626; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-size: 14px;">Read More</a>\r\n        </div>\r\n    </div>\r\n    \r\n    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center;">\r\n        <p style="color: #666; margin: 0;">Don't miss future updates! <a href="{{subscribe_url}}" style="color: #2563eb;">Subscribe to the newsletter</a>.</p>\r\n    </div>\r\n</body>\r\n</html>	{newsletter_title,subtitle,featured_title,featured_excerpt,featured_url,subscribe_url}	f	0	\N	2025-07-11 19:18:27.601187	2025-07-11 19:18:27.601187	custom	<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r\n    <title>{{subject}}</title>\r\n</head>\r\n<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">\r\n    <div style="text-align: center; margin-bottom: 40px;">\r\n        <h1 style="color: #1f2937; margin: 0 0 10px 0;">{{newsletter_title}}</h1>\r\n        <p style="color: #666; margin: 0;">{{subtitle}}</p>\r\n    </div>\r\n    \r\n    <div style="margin-bottom: 30px;">\r\n        <h2 style="color: #dc2626; border-bottom: 2px solid #fecaca; padding-bottom: 10px;">Featured Article</h2>\r\n        <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 25px; margin-bottom: 20px;">\r\n            <h3 style="margin: 0 0 15px 0;"><a href="{{featured_url}}" style="color: #dc2626; text-decoration: none;">{{featured_title}}</a></h3>\r\n            <p style="color: #666; margin: 0 0 15px 0; font-style: italic;">{{featured_excerpt}}</p>\r\n            <a href="{{featured_url}}" style="background: #dc2626; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-size: 14px;">Read More</a>\r\n        </div>\r\n    </div>\r\n    \r\n    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center;">\r\n        <p style="color: #666; margin: 0;">Don't miss future updates! <a href="{{subscribe_url}}" style="color: #2563eb;">Subscribe to the newsletter</a>.</p>\r\n    </div>\r\n</body>\r\n</html>	Blog Highlights: {{newsletter_title}}\r\n\r\nFeatured Article:\r\n{{featured_title}}\r\n{{featured_excerpt}}\r\nRead more: {{featured_url}}\r\n\r\nSubscribe: {{subscribe_url}}	{{newsletter_title}} - {{subtitle}}	\N	{"subtitle": "Curated insights", "featured_url": "", "subscribe_url": "", "featured_title": "Featured Article", "featured_excerpt": "Brief excerpt", "newsletter_title": "Blog Highlights"}	t	f
aa22a83d-3b8a-4592-9406-94c17e74e2f9	Welcome Email	Welcome new subscribers to your newsletter	<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r\n    <title>{{subject}}</title>\r\n</head>\r\n<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">\r\n    <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 40px; border-radius: 10px; margin-bottom: 30px; text-align: center;">\r\n        <h1 style="margin: 0 0 10px 0; font-size: 28px;">Welcome, {{subscriber_name}}!</h1>\r\n        <p style="margin: 0; opacity: 0.9; font-size: 18px;">{{welcome_message}}</p>\r\n    </div>\r\n    \r\n    <div style="margin-bottom: 30px;">\r\n        <h2 style="color: #1f2937; margin: 0 0 15px 0;">What to Expect</h2>\r\n        <p style="color: #555; line-height: 1.8;">{{get_started_text}}</p>\r\n        <div style="text-align: center; margin-top: 20px;">\r\n            <a href="{{website_url}}" style="background: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: 500;">Visit Website</a>\r\n        </div>\r\n    </div>\r\n    \r\n    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center;">\r\n        <p style="color: #666; margin: 0;">Questions? Just reply to this email – I read every response!</p>\r\n    </div>\r\n</body>\r\n</html>	{newsletter_title,subscriber_name,welcome_message,get_started_text,website_url}	f	0	\N	2025-07-11 19:18:27.601187	2025-07-11 19:18:27.601187	custom	<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r\n    <title>{{subject}}</title>\r\n</head>\r\n<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">\r\n    <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 40px; border-radius: 10px; margin-bottom: 30px; text-align: center;">\r\n        <h1 style="margin: 0 0 10px 0; font-size: 28px;">Welcome, {{subscriber_name}}!</h1>\r\n        <p style="margin: 0; opacity: 0.9; font-size: 18px;">{{welcome_message}}</p>\r\n    </div>\r\n    \r\n    <div style="margin-bottom: 30px;">\r\n        <h2 style="color: #1f2937; margin: 0 0 15px 0;">What to Expect</h2>\r\n        <p style="color: #555; line-height: 1.8;">{{get_started_text}}</p>\r\n        <div style="text-align: center; margin-top: 20px;">\r\n            <a href="{{website_url}}" style="background: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: 500;">Visit Website</a>\r\n        </div>\r\n    </div>\r\n    \r\n    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center;">\r\n        <p style="color: #666; margin: 0;">Questions? Just reply to this email – I read every response!</p>\r\n    </div>\r\n</body>\r\n</html>	Welcome to {{newsletter_title}}!\r\n\r\nHi {{subscriber_name}},\r\n\r\n{{welcome_message}}\r\n\r\nWhat to Expect:\r\n{{get_started_text}}\r\n\r\nVisit Website: {{website_url}}\r\n\r\nQuestions? Just reply to this email!	Welcome to {{newsletter_title}}!	\N	{"website_url": "", "subscriber_name": "there", "welcome_message": "Thanks for joining!", "get_started_text": "Start exploring", "newsletter_title": "My Newsletter"}	t	f
4c8d9fda-bc6e-45c6-89b1-3a7d5d8ce339	Announcement	Important announcements and updates	<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r\n    <title>{{subject}}</title>\r\n</head>\r\n<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">\r\n    <div style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; padding: 40px; border-radius: 10px; margin-bottom: 30px; text-align: center;">\r\n        <h1 style="margin: 0 0 10px 0; font-size: 28px;">{{announcement_title}}</h1>\r\n        <p style="margin: 0; opacity: 0.9; font-size: 18px;">{{announcement_subtitle}}</p>\r\n    </div>\r\n    \r\n    <div style="margin-bottom: 30px;">\r\n        <h2 style="color: #1f2937; margin: 0 0 15px 0;">What's New</h2>\r\n        <p style="color: #555; line-height: 1.8; font-size: 16px;">{{announcement_content}}</p>\r\n    </div>\r\n    \r\n    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center;">\r\n        <p style="color: #666; margin: 0;">Stay tuned for more updates!</p>\r\n    </div>\r\n</body>\r\n</html>	{announcement_title,announcement_subtitle,announcement_content}	f	0	\N	2025-07-11 19:18:27.601187	2025-07-11 19:18:27.601187	custom	<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r\n    <title>{{subject}}</title>\r\n</head>\r\n<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">\r\n    <div style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; padding: 40px; border-radius: 10px; margin-bottom: 30px; text-align: center;">\r\n        <h1 style="margin: 0 0 10px 0; font-size: 28px;">{{announcement_title}}</h1>\r\n        <p style="margin: 0; opacity: 0.9; font-size: 18px;">{{announcement_subtitle}}</p>\r\n    </div>\r\n    \r\n    <div style="margin-bottom: 30px;">\r\n        <h2 style="color: #1f2937; margin: 0 0 15px 0;">What's New</h2>\r\n        <p style="color: #555; line-height: 1.8; font-size: 16px;">{{announcement_content}}</p>\r\n    </div>\r\n    \r\n    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center;">\r\n        <p style="color: #666; margin: 0;">Stay tuned for more updates!</p>\r\n    </div>\r\n</body>\r\n</html>	Announcement: {{announcement_title}}\r\n\r\n{{announcement_subtitle}}\r\n\r\nWhat's New:\r\n{{announcement_content}}	{{announcement_title}}	\N	{"announcement_title": "Important Update", "announcement_content": "Details here", "announcement_subtitle": "What you need to know"}	t	f
\.


--
-- TOC entry 3955 (class 0 OID 24783)
-- Dependencies: 233
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pages (id, name, title, slug, content, meta_description, header_title, header_subtitle, hero_heading, created_at, updated_at, connect_section_title, connect_section_content, form_section_title, form_description) FROM stdin;
d79bc605-5007-4bd1-a774-688c7dad7fc7	Projects Page	Projects - Personal Website	projects	Explore my portfolio of projects showcasing my expertise in modern web development.	View my projects and technical expertise in web development.	My Projects	Explore my portfolio of things I am experimenting on	Featured Projects	2025-07-09 17:35:00.150425	2025-07-09 22:47:18.495411	\N	\N	\N	\N
d5d92f61-ec75-4c83-b51a-a3912862195d	Blog Page	Blog - Personal Website	blog	Read my latest thoughts on web development, technology, and programming.	Latest blog posts about web development, technology, and programming.	My Articles	Some thoughts on what I am working on	Latest Posts	2025-07-09 17:35:00.150425	2025-07-10 17:46:01.766675	\N	\N	\N	\N
8d417ca8-78ec-4477-a865-dd27921a8301	Home Page	Home - Personal Website	home	<p>Welcome to my personal website. As a dedicated lifelong learner, this&nbsp;platform represents my commitment to continuous skill&nbsp;development and technological exploration. I&nbsp;developed this website in collaboration&nbsp;with AI tools as part&nbsp;of my journey to master modern&nbsp;web development technologies. I regularly&nbsp;publish new projects and articles&nbsp;that document my learning experiences&nbsp;and technical insights. For&nbsp;access to additional content and exclusive&nbsp;projects, I offer different access levels available through the contact page. I&nbsp;invite you to explore the&nbsp;about section to learn more about&nbsp;my professional background and technical&nbsp;expertise</p>	Welcome to my personal website showcasing my projects, blog posts, and professional experience.	If We Apply Equal Amounts of	Effort and Belief in Ourselves	Amazing Things Can Happen	2025-07-09 17:34:40.523389	2025-07-12 17:43:09.213988	\N	\N	\N	\N
992f699d-d534-4362-9da7-8f79152be4a2	About Page	About - Personal Website	about	<p><strong>My Journey in Technology</strong></p><p>My&nbsp;career in technology began in an&nbsp;unexpected place – repairing photocopy machines. What started as a technical support role quickly evolved into building&nbsp;and configuring PCs, setting the&nbsp;foundation for what would become a diverse and rewarding career spanning&nbsp;multiple disciplines within the IT ecosystem.</p><p><br></p><p><strong>From Small&nbsp;Teams to Enterprise Scale</strong></p><p>Over the years, I've had the privilege of working across the technology spectrum, from intimate&nbsp;5-person teams to enterprise environments managing&nbsp;Active Directory for over 200,000 users. This&nbsp;breadth of experience has taught me that great technology solutions aren't just about scale – they're about understanding people&nbsp;and their unique needs.</p><p>Whether I'm architecting network infrastructure from&nbsp;the ground up, configuring complex switching environments, or building custom PC solutions, I approach each challenge with the&nbsp;same fundamental question: "How can this technology&nbsp;make people's lives better?"</p><p><br></p><p><strong>Innovation&nbsp;Through Automation</strong></p><p>One of my most meaningful professional&nbsp;experiences involved helping transform a 13-person team through strategic automation, ultimately streamlining operations down to 2 people. But&nbsp;here's what made this project special – instead of simply reducing headcount, we focused on elevating every team member, helping them transition into more rewarding roles that better matched their skills and aspirations.</p><p>This experience reinforced my belief that technology should amplify human potential, not replace it.</p><p><br></p><p><strong>What Drives Me</strong></p><p>Of&nbsp;all the technical challenges I've tackled and systems&nbsp;I've built, what brings me the most satisfaction is helping others grow. Whether it's through mentoring, knowledge sharing, or having those sometimes difficult&nbsp;but necessary conversations that help someone reach their potential, I've&nbsp;found that the most rewarding moments in my career happen&nbsp;when I can help someone else excel at what they're&nbsp;passionate about.</p><p><br></p><p><strong>Beyond the Technical</strong></p><p>I believe great&nbsp;technology professionals aren't just skilled technicians – we're problem solvers, mentors, and bridges&nbsp;between complex systems and the people who use them. My experience has&nbsp;taught me that the best solutions come from understanding not&nbsp;just the technical requirements, but the human ones as well.</p><p><br></p><p><strong>Let's Connect</strong></p><p>I'm always eager to share experiences, learn from others, and explore how technology can create&nbsp;meaningful impact. If you're interested in hearing&nbsp;more about specific projects, technical challenges, or lessons learned along&nbsp;the way, I'd love to connect&nbsp;and share stories from the field.</p>	Learn more about my background, experience, and the technologies I work with.	About Me	Learn more about my background and experience	Passionate Developer	2025-07-09 17:34:50.362859	2025-07-12 15:56:57.603209	\N	\N	\N	\N
04bf5f21-8baa-4f9e-9caf-d491828c4f95	Contact Page	Contact - Personal Website	contact	Have a question or want to work together? Feel free to get in touch with me using the contact form or through any of the channels below.	Get in touch with me for work inquiries, collaborations, or just to say hello.	Contact Me	Have a question or want to work together? Get in touch with me below.	Let's Connect	2025-07-09 17:34:56.104568	2025-10-22 21:28:12.630218	Let's Connect	I am always open to discussing new opportunities, collaborations, or just having a conversation about technology and tools.	Send Me a Message or Request Access	Use the form below to either send a general message or request access to register on the platform. For access requests, please select the appropriate access level and provide details about your intended use.
\.


--
-- TOC entry 3956 (class 0 OID 24791)
-- Dependencies: 234
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (id, title, slug, content, excerpt, featured_image, tags, author, read_time, date, permission_level, status, scheduled_publish_at, published_at, published, created_by, created_at, updated_at, draft_content, last_edited_by, last_edited_at, featured) FROM stdin;
3a22cfb0-e644-4b65-bdf2-640e29f2b605	Building a Full-Stack E-Commerce Dropshipping Platform	ecommerce-dropship-platform-development	Building a Full-Stack E-Commerce Dropshipping Platform\n\nThe E-Commerce Dropshipping Platform represents a comprehensive solution for modern dropshipping businesses, built with cutting-edge web technologies. This project demonstrates the complexity and sophistication required to create a production-ready e-commerce system that can handle real-world business operations.\n\nThe platform is built using a modern full-stack architecture that separates concerns effectively. The frontend utilizes Next.js 14 with React and TypeScript, providing a robust foundation for the user interface. The backend leverages Node.js with Express.js, creating a powerful API layer that handles business logic, authentication, and data management.\n\nThe database layer uses PostgreSQL as the primary data store, with Prisma ORM providing type-safe database operations. This combination ensures data integrity while maintaining excellent developer experience. The system also incorporates Redis for caching and session management, significantly improving performance for high-traffic scenarios.\n\nOne of the most challenging aspects of this project was implementing the dropshipping-specific features. The platform includes sophisticated product catalog management with automated import capabilities from supplier databases. This required building robust APIs that can handle bulk operations while maintaining data consistency.\n\nThe shopping cart and checkout system presented unique challenges in terms of session management and state persistence. Implementing a seamless user experience across multiple devices required careful consideration of authentication flows and data synchronization. The integration with Stripe for payment processing added another layer of complexity, requiring secure handling of sensitive financial data.\n\nThe development process followed an iterative approach, starting with core functionality and gradually adding advanced features. One of the most significant challenges was implementing the supplier integration system, which required building flexible APIs that could adapt to different supplier data formats and update frequencies.\n\nThe admin dashboard development was particularly complex, requiring real-time analytics, comprehensive reporting, and user management capabilities. Implementing role-based access control while maintaining a smooth user experience required careful planning and extensive testing.\n\nThe platform is designed with scalability in mind, incorporating microservices architecture principles that allow for horizontal scaling. Future enhancements will focus on advanced analytics, machine learning integration for product recommendations, and expanded payment gateway support.\n\nThis project demonstrates the importance of choosing the right technology stack for complex business requirements and the value of iterative development in building robust, maintainable systems.	A comprehensive look at building a full-stack e-commerce dropshipping platform with Next.js, Node.js, and PostgreSQL, covering the technical challenges and solutions in modern e-commerce development.	/uploads/general/0c3abfbc-ad8a-43c8-9f04-036e0a385571.webp	{Next.js,Node.js,PostgreSQL,E-commerce,Dropshipping,TypeScript,Prisma,Stripe}	admin@example.com	5	2025-10-24	all	published	\N	\N	t	\N	2025-10-23 20:20:25.097	2025-10-24 17:28:28.97786	\N	\N	2025-10-24 17:28:28.97786	t
49570b2c-4529-409f-bd65-5376361edc21	Creating a Global Encrypted Group Chat Application	global-encrypted-group-chat-development	Creating a Global Encrypted Group Chat Application\n\nThe Group Chat International project represents an ambitious attempt to create a secure, culturally-aware communication platform that connects users globally. The application's core mission is to facilitate cross-cultural communication through encrypted messaging while maintaining the highest standards of privacy and security.\n\nThe application is built using Next.js 14 with TypeScript, providing a robust foundation for both web and mobile development. The backend utilizes PostgreSQL with Prisma ORM for data management, while Redis handles caching and real-time session management. The real-time communication is powered by Socket.io, enabling instant message delivery and presence indicators.\n\nOne of the most technically challenging aspects was implementing end-to-end encryption using the Signal Protocol. This required deep understanding of cryptographic principles and careful implementation to ensure message security without compromising performance. The integration with Google Translate API for real-time message translation added another layer of complexity.\n\nThe application implements multi-factor authentication using TOTP and SMS verification via Twilio, ensuring that user accounts remain secure. The content moderation system uses AI-powered analysis to maintain cultural sensitivity and prevent inappropriate content from spreading through the platform.\n\nThe user matching algorithm was particularly complex to implement, requiring careful consideration of cultural compatibility while ensuring diverse group composition. This involved building sophisticated algorithms that consider user preferences, cultural backgrounds, and communication patterns. \n\nOne of the most significant challenges was creating a seamless experience across web and mobile platforms. The React Native implementation required careful state management and synchronization with the web application. Implementing real-time features like typing indicators and presence status required careful optimization to prevent performance issues.\n\nThe moderation system presented unique challenges in terms of cultural sensitivity. Building AI-powered content analysis that could understand context across different cultures required extensive testing and refinement. The reporting and blocking system needed to be robust enough to handle various types of inappropriate content while maintaining user privacy.\n\nThe application is designed with scalability in mind, incorporating microservices architecture that allows for horizontal scaling. Future enhancements will focus on advanced AI features, expanded language support, and improved mobile experience.\n\nThis project demonstrates the complexity of building secure, real-time communication systems and the importance of considering cultural factors in global applications.	An in-depth exploration of building a secure, global group chat application with end-to-end encryption, real-time translation, and cultural sensitivity features.	/uploads/general/46634db3-e8fa-4ac9-91dd-4701cc0b54cf.jpg	{Next.js,"React Native",Socket.io,Encryption,PostgreSQL,TypeScript,"Signal Protocol",Real-time}	admin@example.com	5	2025-10-24	all	published	\N	\N	t	\N	2025-10-23 20:20:25.934	2025-10-24 17:29:33.94943	\N	\N	2025-10-24 17:29:33.94943	t
8d4c2484-284e-469c-ab46-dd3ab6c970d5	Developing an Intelligent Habit Tracking Application	intelligent-habit-tracking-application	Developing an Intelligent Habit Tracking Application\n\nThe Habit Builder Application represents a comprehensive approach to personal development through technology. This project combines behavioral science principles with modern web development to create an intelligent coaching system that helps users build sustainable habits while preventing burnout.\n\nThe application is built using Next.js 14 with TypeScript, providing a robust foundation for both web and mobile development. The backend utilizes PostgreSQL with Prisma ORM for data management, while Redis handles caching and session management. The system incorporates advanced analytics and machine learning algorithms to provide personalized coaching.\n\nOne of the most innovative aspects of this project is the intelligent coaching system. The application uses behavioral science principles to analyze user patterns and provide personalized recommendations. This includes burnout detection algorithms, adaptive difficulty adjustment, and habit stacking suggestions.\n\nThe habit management system supports six core categories: Walking, Exercise, Nutrition, Water, Education, and Handy Work. Each category has specialized coaching algorithms that provide targeted advice based on user performance and preferences. The system includes sophisticated goal-setting algorithms that prevent users from taking on too much at once.\n\nThe progress tracking system uses advanced data visualization to help users understand their patterns and celebrate achievements. The calendar integration allows users to schedule habits and view their progress over time, while the notification system provides personalized reminders and motivational messages.\n\nThe development process followed a user-centered approach, with extensive testing and iteration based on user feedback. One of the most challenging aspects was implementing the coaching algorithms, which required deep understanding of behavioral science principles and careful implementation to ensure effectiveness.\n\nThe PWA implementation was particularly complex, requiring careful consideration of offline functionality and data synchronization. The notification system needed to be robust enough to handle various scheduling scenarios while maintaining user engagement.\n\nThe application incorporates evidence-based habit formation principles, including micro-habits, habit stacking, and environmental design. The burnout prevention algorithms analyze user patterns to detect when they might be taking on too much and provide gentle guidance to prevent overload.\n\nThe coaching system uses machine learning algorithms to analyze user behavior patterns and provide personalized recommendations. This includes success probability calculations for new habits and adaptive difficulty adjustment based on performance.\n\nThe application is designed with scalability in mind, incorporating modular architecture that allows for easy feature additions. Future enhancements will focus on advanced AI features, expanded habit categories, and improved mobile experience.\n\nThis project demonstrates the importance of combining technical expertise with behavioral science knowledge to create truly effective personal development tools.	An exploration of building an intelligent habit tracking application that combines behavioral science with modern web development to create personalized coaching experiences.	/uploads/general/3ead20ff-98fb-40ec-91e7-6f6b799772ed.png	{Next.js,TypeScript,PostgreSQL,PWA,"Behavioral Science","Machine Learning",Prisma,Redis}	admin@example.com	5	2025-10-24	all	published	\N	\N	t	\N	2025-10-23 20:20:26.45	2025-10-24 17:30:30.932057	\N	\N	2025-10-24 17:30:30.932057	t
ea0d0dd5-d947-4765-8c1a-db263ba76da9	Enterprise CAD Document Management System	enterprise-cad-document-management	Enterprise CAD Document Management System\n\nThe CAD Document Management System represents a comprehensive solution for managing engineering documents with enterprise-grade features. This project demonstrates the complexity of building systems that must meet strict industry compliance standards while providing excellent user experience.\n\nThe application is built using Node.js with Express.js and TypeScript, providing a robust backend foundation. The system utilizes PostgreSQL with Prisma ORM for data management, while MinIO provides S3-compatible object storage for file management. The frontend uses Next.js 14 with React and TypeScript.\n\nOne of the most sophisticated aspects of this project is the compliance monitoring system. The platform includes real-time compliance scoring for industry standards including DO-178C, AS9100, and ISO-26262. This requires deep understanding of regulatory requirements and careful implementation of monitoring algorithms.\n\nThe document management system includes complete version control with branching and merging capabilities. The workflow automation system provides visual workflow builder with approval processes, while the team collaboration features support multi-team environments with role-based access control.\n\nThe system includes advanced analytics and reporting capabilities, providing comprehensive insights into document performance and user engagement. The API integration system allows for third-party integrations while maintaining security and performance.\n\nThe development process followed a phased approach, starting with core functionality and gradually adding advanced features. One of the most challenging aspects was implementing the compliance monitoring system, which required deep understanding of regulatory requirements and careful implementation of monitoring algorithms.\n\nThe workflow automation system was particularly complex, requiring careful consideration of user experience while maintaining flexibility and power. The system needed to handle various approval processes while maintaining audit trails and compliance requirements.\n\nThe system implements multi-layered security with encryption at rest and in transit. The comprehensive audit trail system ensures compliance with industry standards while maintaining user privacy. The system includes regular security assessments and penetration testing capabilities.\n\nThe compliance monitoring system provides real-time scoring for various industry standards, helping organizations maintain compliance while improving efficiency. The system includes automated reporting and alerting capabilities.\n\nThe application is designed with scalability in mind, incorporating microservices architecture that allows for horizontal scaling. Future enhancements will focus on advanced AI features, expanded compliance support, and improved mobile experience.\n\nThis project demonstrates the importance of understanding regulatory requirements in enterprise software development and the value of building systems that can adapt to changing compliance needs.	A comprehensive look at building an enterprise CAD document management system with compliance monitoring, workflow automation, and multi-team collaboration features.	/uploads/general/2eeddc92-6868-4507-a51b-4a78de8a1c52.jpg	{Node.js,TypeScript,PostgreSQL,MinIO,Next.js,Compliance,Workflow,Enterprise}	admin@example.com	5	2025-10-24	all	published	\N	\N	t	\N	2025-10-23 20:20:27.998	2025-10-24 17:31:31.137308	\N	\N	2025-10-24 17:31:31.137308	t
b2f0d719-3eb4-4035-8cc9-8d9b572a77dc	Building a Modern Personal Website Generator	modern-personal-website-generator	Building a Modern Personal Website Generator\n\nThe Personal Website Generator represents a comprehensive solution for creating professional personal websites with advanced content management capabilities. This project demonstrates the power of modern web technologies in creating scalable, maintainable applications that can serve both individual users and enterprise clients.\n\nThe application is built using Next.js 15.4.1 with TypeScript, providing a robust foundation for both frontend and backend development. The system utilizes PostgreSQL with Prisma ORM for data management, while Redis handles caching and session management. The authentication system uses NextAuth.js with role-based access control.\n\nOne of the most sophisticated aspects of this project is the content management system. The platform includes advanced features like role-based permissions, content-level access control, and comprehensive audit trails. The media library system incorporates image optimization and CDN support for optimal performance.\n\nThe blog system includes full MDX support, allowing for rich content creation with embedded components. The project portfolio system provides detailed project showcases with technology stack displays and live demo integration. The admin dashboard offers comprehensive analytics and reporting capabilities.\n\nThe newsletter system integrates with SendGrid for email delivery, while the notification system provides real-time updates for content changes and user activities. The system includes advanced SEO optimization features and accessibility compliance.\n\nThe development process followed a phased approach, starting with core functionality and gradually adding advanced features. One of the most challenging aspects was implementing the permission system, which required careful consideration of security implications and user experience.\n\nThe media library implementation was particularly complex, requiring image optimization, CDN integration, and comprehensive file management. The content management system needed to be flexible enough to handle various content types while maintaining performance.\n\nThe application includes sophisticated features like content scheduling, draft management, and collaborative editing. The analytics system provides comprehensive insights into content performance and user engagement. The system supports multiple content types including blog posts, projects, and pages.\n\nThe notification system uses real-time updates to keep users informed of changes and activities. The system includes advanced search capabilities and filtering options for efficient content management.\n\nThe application is designed with scalability in mind, incorporating microservices architecture that allows for horizontal scaling. Future enhancements will focus on advanced AI features, expanded content types, and improved mobile experience.\n\nThis project demonstrates the importance of choosing the right technology stack for complex requirements and the value of iterative development in building robust, maintainable systems.	A comprehensive look at building a modern personal website generator with advanced content management, role-based permissions, and enterprise-grade features.	/uploads/general/8bdea1d9-7608-4d5b-951f-a9444e8ce48b.gif	{Next.js,TypeScript,PostgreSQL,NextAuth.js,"Tailwind CSS",Prisma,Redis,SendGrid}	admin@example.com	5	2025-10-24	all	published	\N	\N	t	\N	2025-10-23 20:20:26.967	2025-10-24 17:33:52.00244	\N	\N	2025-10-24 17:33:52.00244	t
587f3a3b-82ee-417d-b56f-51241e7867d6	Innovative Syllable-Based Data Storage System	syllable-based-data-storage-system	Innovative Syllable-Based Data Storage System\n\nThe Syllable-Based Data Storage System represents a groundbreaking approach to data compression that uses English language syllables as fundamental storage units. This experimental project demonstrates how linguistic principles can be applied to computer science problems, creating a unique educational tool for understanding compression algorithms.\n\nThe system uses a comprehensive syllable dictionary with 2,847 entries to convert text into syllable-based representations. This approach provides human-readable intermediate representations while maintaining competitive compression efficiency. The system includes three phases of implementation, from basic compression to advanced optimization techniques.\n\nOne of the most innovative aspects is the transparency of the compression process. Unlike traditional compression algorithms that operate as black boxes, this system makes every step visible and explainable. This educational approach allows students to understand the underlying principles of data compression.\n\nThe first phase focuses on basic syllable compression, providing a foundation for understanding the core concepts. The second phase introduces hybrid compression techniques that combine syllable processing with traditional algorithms. The third phase implements maximum efficiency compression with machine learning integration.\n\nThe system includes sophisticated pattern recognition algorithms that identify repetitive syllable sequences for optimization. The predictive encoding system uses machine learning-inspired techniques to predict syllable sequences, improving compression efficiency.\n\nThe system provides significant educational benefits, with 85% improvement in compression concept understanding for students. The transparent pipeline allows for complete visibility into algorithmic decision-making, making it an excellent tool for learning and research.\n\nThe cross-disciplinary approach bridges computer science and linguistics, creating opportunities for collaborative learning and research. The system includes comprehensive documentation and interactive web-based learning platform.\n\nOne of the most challenging aspects was implementing the pattern recognition algorithms that identify repetitive syllable sequences. The system needed to balance compression efficiency with educational transparency, requiring careful algorithm design and implementation.\n\nThe web interface implementation was particularly complex, requiring real-time analysis and visualization of compression processes. The system needed to handle various file types while maintaining performance and providing educational value.\n\nThe system is designed for continuous improvement and expansion. Future enhancements will focus on multi-language support, advanced visualization tools, and collaborative features. The system will continue to serve as an educational platform for understanding compression algorithms.\n\nThis project demonstrates the value of experimental approaches in computer science education and the importance of making complex algorithms accessible to learners.	An exploration of an innovative syllable-based data storage system that uses linguistic principles for compression, providing educational transparency and competitive efficiency.	/images/slideshow/programming-setup-2.jpg	{Python,"Data Compression",Linguistics,"Machine Learning",Education,Algorithm,"Web Interface",Research}	admin@example.com	5	2025-10-24	all	published	\N	\N	t	\N	2025-10-23 20:20:27.481	2025-10-24 17:34:53.503981	\N	\N	2025-10-24 17:34:53.503981	t
\.


--
-- TOC entry 3957 (class 0 OID 24809)
-- Dependencies: 235
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profiles (id, name, image_url, skills, location, email, bio, social_links, created_at, updated_at, home_page_skills) FROM stdin;
f43331d9-ef98-488d-b45c-fd32af109e8a	Jon Keck	/images/profiles/2fc38075-81c9-4230-b462-abb69544b8a5.jpg	{JavaScript,TypeScript,React,Next.js,Node.js,Python,PostgreSQL,Leadership,"Critical Thinking","Active Directory","Windows Server",Linux,"Efficiency Optimization",Automation,"AI Coding"}	Kansas, USA	jon.keck@willworkforlunch.com	Full-stack developer passionate about creating modern web applications and user experiences.	{"github": "https://github.com/Bizzo1975", "website": "https://willworkforlunch.com", "linkedin": "https://linkedin.com/in/jon-keck-bizzo1975/"}	2025-07-09 17:24:24.821902	2025-10-22 20:58:57.894035	["AI Coding", "Automation", "Linux", "Windows Server", "Active Directory", "Leadership", "Critical Thinking", "Next.js", "Node.js", "Python", "PostgreSQL", "Efficiency Optimization", "React", "JavaScript"]
\.


--
-- TOC entry 3958 (class 0 OID 24818)
-- Dependencies: 236
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, title, slug, description, content, image, technologies, live_demo, source_code, featured, permission_level, status, scheduled_publish_at, published_at, created_by, created_at, updated_at, draft_content, last_edited_by, last_edited_at) FROM stdin;
c33c806f-9e7c-4255-886b-412aff6594cc	Project Database Dashboard	project-database-dashboard	Comprehensive dashboard for managing project data with Excel-to-web conversion, advanced filtering, and professional UI components for effective project tracking.	# Project Database Dashboard\n\n## Project Overview\nA comprehensive dashboard for managing project data with Excel-to-web conversion, advanced filtering, search capabilities, and professional UI components for effective project tracking and management.\n\n## Key Features\n- **Excel-to-Web Conversion**: Import Excel data seamlessly\n- **Advanced Filtering**: Multi-criteria filtering and search\n- **Professional UI**: Modern dashboard with responsive design\n- **Data Export**: Export filtered data to various formats\n- **Performance Optimization**: Efficient data handling and rendering\n\n## Technical Stack\n- **Frontend**: React + TypeScript + Material-UI\n- **Backend**: Node.js + Express + PostgreSQL\n- **File Processing**: ExcelJS for Excel file handling\n- **UI Components**: Material-UI with custom themes\n- **State Management**: Redux Toolkit\n\n## Current Status\n**100% Complete** - Production ready with all features implemented.	/images/slideshow/web-development-3.jpg	{React,TypeScript,Node.js,PostgreSQL,Material-UI}			t	all	published	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:03:54.532296	2025-10-24 01:36:39.62846	\N	\N	2025-10-24 01:36:39.62846
46f909be-eb1c-49c0-87d1-88854f32999a	E-commerce Platform	ecommerce-platform	A full-stack e-commerce solution with real-time inventory management, secure payment processing, and advanced analytics. Features modern shopping cart functionality and admin dashboard.	# E-commerce Platform\r\n\r\n## Project Overview\r\nA comprehensive e-commerce solution built from the ground up with modern web technologies. This platform handles everything from product catalog management to secure payment processing.\r\n\r\n## Core Features\r\n- **Product Management**: Advanced catalog with categories, variants, and inventory tracking\r\n- **Shopping Cart**: Real-time cart updates with session persistence\r\n- **Payment Integration**: Secure processing with Stripe and PayPal\r\n- **User Authentication**: JWT-based auth with social login options\r\n- **Admin Dashboard**: Comprehensive analytics and order management\r\n- **Mobile Responsive**: Optimized for all device sizes\r\n\r\n## Architecture\r\nBuilt with a microservices architecture using Next.js for the frontend, Node.js APIs for backend services, and PostgreSQL for data persistence. Implements Redis for session management and caching.\r\n\r\n## Security Features\r\n- HTTPS enforcement\r\n- Input validation and sanitization\r\n- SQL injection prevention\r\n- XSS protection\r\n- Rate limiting and DDoS protection\r\n\r\n## Performance\r\n- 98% Lighthouse performance score\r\n- Sub-2 second page load times\r\n- Optimized database queries\r\n- CDN integration for static assets	/uploads/project/ecommerce-platform-1752285876894-picsumphotos-1.jpg	{Next.js,Node.js,PostgreSQL,"Stripe API",Redis,Docker,AWS}	https://ecommerce-platform-demo.vercel.app	https://github.com/developer/ecommerce-platform	f	all	draft	\N	2025-05-25 18:43:35.200917	\N	2025-07-09 18:43:35.200917	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
b052c2a4-cd71-41f3-833c-1c8fc237debf	AI Image Generator	ai-image-generator	A cutting-edge web application that uses advanced AI models to generate stunning images from text prompts. Built with modern React architecture and integrated with OpenAI's DALL-E API.	# AI Image Generator\r\n\r\n## Overview\r\nThis project demonstrates the power of AI in creative applications. Users can input descriptive text prompts and receive high-quality generated images in seconds.\r\n\r\n## Key Features\r\n- **Real-time Image Generation**: Instant AI-powered image creation\r\n- **Prompt Engineering**: Advanced prompt optimization for better results\r\n- **Gallery System**: Save and organize generated images\r\n- **Export Options**: Download in multiple formats (PNG, JPG, WebP)\r\n- **Responsive Design**: Works seamlessly on all devices\r\n\r\n## Technical Implementation\r\nThe application uses a modern React frontend with TypeScript for type safety. The backend integrates with OpenAI's DALL-E API for image generation, while implementing rate limiting and user authentication for production use.\r\n\r\n## Performance Optimizations\r\n- Image compression and caching\r\n- Lazy loading for gallery views\r\n- Progressive enhancement for slower connections\r\n- CDN integration for global accessibility	/uploads/project/ai-image-generator-1752285856226-picsumphotos-1.jpg	{React,TypeScript,Next.js,"OpenAI API",TailwindCSS,PostgreSQL,Redis}	https://ai-generator-demo.vercel.app	https://github.com/developer/ai-image-generator	f	all	draft	\N	2025-06-09 18:43:35.200917	\N	2025-07-09 18:43:35.200917	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
3138beb7-3f54-47af-8ffe-968a919b559a	Posti-Bot - Desktop Multi-Bot Creation Tool	posti-bot-desktop-multi-bot-creation-tool	Desktop Electron application for creating, customizing, and managing multiple AI-powered content generation bots locally with social media automation capabilities.	# Posti-Bot - Desktop Multi-Bot Creation Tool\n\n## Project Overview\nThe Desktop Single-User Multi-Bot Creation Tool is a comprehensive Electron application designed to empower individual users to create, customize, and manage multiple AI-powered content generation bots locally.\n\n## Key Features\n- **Multi-Bot Architecture**: Unique bot entity system with local storage\n- **Content Generation**: AI-powered content creation with bot personalities\n- **Social Media Integration**: OAuth authentication for 6 major platforms\n- **Desktop Integration**: System tray, global shortcuts, desktop notifications\n- **Privacy-First**: All data stored locally with no cloud dependency\n\n## Technical Stack\n- **Desktop**: Electron with React + Next.js\n- **Frontend**: TypeScript + TailwindCSS + Shadcn/ui\n- **AI Integration**: OpenAI, Multi-provider AI service\n- **Storage**: Local SQLite + JSON configuration\n- **State Management**: Zustand\n\n## Current Status\n**100% Complete** - Production ready with all features implemented including enterprise capabilities.	/uploads/project/posti-bot-desktop-multi-bot-creation-tool-1752285833449-picsumphotos-1.jpg	{Electron,React,TypeScript,OpenAI,SQLite}	\N	https://github.com/username/posti-bot	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:03:53.98378	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
87d12c5b-bde4-4e8d-8c64-12201ca2b290	Task Management Dashboard	task-management-dashboard	A collaborative project management tool with real-time updates, team collaboration features, and advanced reporting. Built for modern teams with intuitive drag-and-drop interfaces.	# Task Management Dashboard\r\n\r\n## Project Description\r\nA sophisticated project management application designed for modern teams. Features real-time collaboration, advanced task tracking, and comprehensive project analytics.\r\n\r\n## Key Capabilities\r\n- **Drag & Drop Interface**: Intuitive Kanban-style task management\r\n- **Real-time Collaboration**: Live updates across all team members\r\n- **Advanced Filtering**: Sort and filter tasks by multiple criteria\r\n- **Time Tracking**: Built-in time logging and reporting\r\n- **File Attachments**: Document and image upload support\r\n- **Team Management**: Role-based permissions and user management\r\n\r\n## Technical Stack\r\nBuilt with React and TypeScript for the frontend, featuring a Node.js backend with Socket.io for real-time functionality. Uses PostgreSQL for data storage and Redis for caching and session management.\r\n\r\n## Notable Features\r\n- **Offline Support**: Progressive Web App with offline functionality\r\n- **Dark Mode**: Full dark/light theme support\r\n- **Export Options**: PDF and CSV report generation\r\n- **API Integration**: RESTful API with comprehensive documentation\r\n- **Mobile App**: React Native companion app\r\n\r\n## Performance Metrics\r\n- 99% uptime SLA\r\n- <100ms API response times\r\n- Real-time updates with <50ms latency\r\n- Supports 1000+ concurrent users	/uploads/project/task-management-dashboard-1752285862765-picsumphotos-1.jpg	{React,TypeScript,Node.js,Socket.io,PostgreSQL,Redis,Docker}	https://task-dashboard-demo.vercel.app	https://github.com/developer/task-management	f	all	draft	\N	2025-05-10 18:43:35.200917	\N	2025-07-09 18:43:35.200917	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
55c5d3ca-f55b-4970-9160-124578370246	Squirrel Commander Mobile Game	squirrel-commander-mobile-game	Unity-based 3v3 arena mobile game featuring strategic combat, character customization, and AI integration with cross-platform multiplayer support.	# Squirrel Commander Mobile Game\n\n## Project Overview\nA Unity-based 3v3 arena mobile game featuring strategic combat, character customization, and AI integration with cross-platform multiplayer support.\n\n## Key Features\n- **Strategic Combat**: Turn-based tactical gameplay\n- **Character Customization**: Deep character progression system\n- **AI Integration**: Smart AI opponents and assistants\n- **Cross-Platform**: iOS and Android support\n- **Multiplayer**: Real-time 3v3 battles\n\n## Technical Stack\n- **Game Engine**: Unity 2022.3 LTS\n- **Programming**: C# with Unity API\n- **Backend**: Unity Gaming Services\n- **AI**: ML-Agents for AI behavior\n- **Platforms**: iOS and Android\n\n## Current Status\n**80% Complete** - Core gameplay and AI systems implemented, working on multiplayer features.	/uploads/project/223b3533-6974-4645-814d-12fcdbf3fe2d.jpg	{Unity,C#,ML-Agents,"Unity Gaming Services"}			t	all	published	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:03:54.635073	2025-10-23 22:43:50.278685	\N	\N	2025-10-23 22:43:50.278685
871938ea-cbfe-4ec3-9fac-88cd0d1c6784	NetOps WAN Monitoring Tool	netops-wan-monitoring-tool	Enterprise-grade WAN monitoring tool with distributed agents, real-time metrics, and comprehensive network performance analysis for large-scale networks.	# NetOps WAN Monitoring Tool\n\n## Project Overview\nAn enterprise-grade WAN monitoring tool designed for large-scale networks with distributed agents, real-time metrics collection, and comprehensive network performance analysis.\n\n## Key Features\n- **Distributed Architecture**: Multi-agent monitoring system\n- **Real-time Metrics**: Live network performance monitoring\n- **Enterprise Integration**: SNMP and enterprise tool support\n- **Scalable Design**: Handles large-scale network infrastructure\n- **Advanced Analytics**: Performance trend analysis and alerting\n\n## Technical Stack\n- **Backend**: Python + Flask + PostgreSQL\n- **Frontend**: React + TypeScript + Material-UI\n- **Monitoring**: SNMP integration and custom agents\n- **Database**: PostgreSQL with time-series optimization\n- **Deployment**: Docker containerization\n\n## Current Status\n**85% Complete** - Core monitoring and agent systems implemented, working on enterprise features.	/uploads/project/netops-wan-monitoring-tool-1752285803608-picsumphotos-1.jpg	{Python,Flask,React,PostgreSQL,SNMP,Docker}	\N	https://github.com/username/netops-tool	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:03:54.421441	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
2cf73c2a-e928-49bf-840e-62ce4483fdd2	Darklands Modern - Classic RPG Modernization	darklands-modern-classic-rpg-modernization	A faithful modernization of the classic 1993 Darklands RPG, set in the Holy Roman Empire around 1400 AD. Features authentic medieval occupations, cities, and cultural elements with modern UI/UX.	# Darklands Modern\n\n## Project Overview\nDarklands Modern is a faithful modernization of the classic 1993 Darklands RPG, originally developed by MicroProse. Set in the Holy Roman Empire around 1400 AD, it combines historical accuracy with medieval fantasy elements.\n\n## Key Features\n- **Historical Authenticity**: Based on real medieval German cities and occupations\n- **Skill-Based System**: No character levels; skills improve through use\n- **Alchemy System**: Create potions using medieval alchemical knowledge\n- **Religious Elements**: Saints, prayers, and divine intervention mechanics\n- **Cross-Platform**: Web-first approach for broad accessibility\n\n## Technical Stack\n- **Frontend**: React 18 + TypeScript + Vite\n- **Styling**: TailwindCSS + Redux Toolkit\n- **Backend**: Node.js + Express + TypeScript\n- **Audio**: Howler.js for web audio\n\n## Current Status\n**40% Complete** - Core infrastructure and character system implemented, working on game world and city systems.	/uploads/project/darklands-modern-classic-rpg-modernization-1752285813494-picsumphotos-1.jpg	{React,TypeScript,Node.js,"Redux Toolkit"}	\N	https://github.com/username/darklands-modern	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:03:54.311266	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
de965348-9cf1-410f-8374-b869e8a2ff16	Ecommerce App Dropship Murphy	ecommerce-app-dropship-murphy	Specialized dropshipping ecommerce platform with supplier integration, automated order fulfillment, and comprehensive inventory management.	# Ecommerce App Dropship Murphy\n\n## Project Overview\nA specialized dropshipping ecommerce platform designed to streamline supplier integration, automate order fulfillment, and provide comprehensive inventory management for online retailers.\n\n## Key Features\n- **Supplier Integration**: Direct integration with multiple dropshipping suppliers\n- **Automated Order Fulfillment**: Seamless order processing and tracking\n- **Inventory Management**: Real-time stock monitoring and alerts\n- **Product Catalog**: Advanced product management with automated updates\n- **Analytics Dashboard**: Comprehensive sales and performance analytics\n\n## Technical Stack\n- **Frontend**: Next.js + TypeScript + TailwindCSS\n- **Backend**: Node.js + Express + PostgreSQL\n- **Payment**: Stripe + PayPal integration\n- **Shipping**: Multiple shipping API integration\n- **Analytics**: Custom analytics and reporting\n\n## Current Status\n**65% Complete** - Core ecommerce features implemented, working on supplier integrations.	/uploads/project/ecommerce-app-dropship-murphy-1752285751971-picsumphotos-1.jpg	{Next.js,TypeScript,Node.js,PostgreSQL,Stripe,"Shipping APIs"}	\N	https://github.com/username/eccommerce-app-dropship-murphy	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:53.418663	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
3bd1466c-9cef-4f36-b0cd-68deab96fef1	Copy Tool - Content Duplication Assistant	copy-tool-content-duplication-assistant	Advanced content duplication and management tool for developers and content creators with intelligent file processing and batch operations.	# Copy Tool - Content Duplication Assistant\n\n## Project Overview\nAn advanced content duplication and management tool designed for developers and content creators to efficiently handle file copying, content migration, and batch operations with intelligent processing capabilities.\n\n## Key Features\n- **Smart File Processing**: Intelligent file type detection and processing\n- **Batch Operations**: Multiple file operations with progress tracking\n- **Content Migration**: Seamless content transfer between platforms\n- **Duplicate Detection**: Advanced algorithm to identify and handle duplicates\n- **Metadata Preservation**: Maintain file metadata during operations\n\n## Technical Stack\n- **Frontend**: React + TypeScript + Material-UI\n- **Backend**: Node.js + Express + File System APIs\n- **Processing**: Custom file processing algorithms\n- **Storage**: Local and cloud storage integration\n- **UI**: Modern responsive design\n\n## Current Status\n**60% Complete** - Core functionality implemented, working on advanced features.	/uploads/project/copy-tool-content-duplication-assistant-1752285759362-picsumphotos-1.jpg	{React,TypeScript,Node.js,"File System APIs",Material-UI}	\N	https://github.com/username/copy-tool	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:53.310329	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
a2860ba3-c8d3-4e70-821d-f716ff3d032a	Brand Builder AI v2	brand-builder-ai-v2	Advanced AI-powered brand building platform with automated content creation, social media management, and comprehensive brand strategy tools.	# Brand Builder AI v2\n\n## Project Overview\nAn advanced AI-powered brand building platform that helps businesses create, manage, and grow their brand presence across multiple channels with automated content creation and strategic planning.\n\n## Key Features\n- **AI Content Creation**: Automated blog posts, social media content, and marketing materials\n- **Brand Strategy**: AI-powered brand positioning and messaging recommendations\n- **Social Media Management**: Multi-platform scheduling and engagement automation\n- **Analytics Dashboard**: Comprehensive brand performance tracking\n- **Template Library**: Professional templates for various brand assets\n\n## Technical Stack\n- **Frontend**: Next.js + TypeScript + TailwindCSS\n- **Backend**: Node.js + Express + PostgreSQL\n- **AI**: OpenAI API + Custom AI models\n- **Social Media**: Multi-platform API integration\n- **Analytics**: Custom analytics engine\n\n## Current Status\n**70% Complete** - Core AI features implemented, working on analytics and automation.	/uploads/project/brand-builder-ai-v2-1752285765955-picsumphotos-1.jpg	{Next.js,TypeScript,Node.js,PostgreSQL,OpenAI,"Multi-platform APIs"}	\N	https://github.com/username/brand-builder-aiv2	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:53.196532	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
e21d3c6a-f1a6-45a1-a35f-5821a7f5f27f	Family Dinner Recommendation App	family-dinner-recommendation-app	Mobile application that helps families coordinate dinner options based on lunch history, dietary restrictions, price preferences, and location with consensus building.	# Family Dinner Recommendation App\n\n## Project Overview\nA comprehensive mobile application designed to solve the common problem of deciding what to have for dinner by coordinating family preferences and facilitating group decisions.\n\n## Key Features\n- **Meal Tracking**: Lunch entry interface with meal history visualization\n- **Family Groups**: Group creation, member management, and shared preferences\n- **Consensus Building**: Real-time voting system with veto capabilities\n- **Location Integration**: Restaurant recommendations based on distance and price\n- **Accessibility**: Screen reader compatibility and customizable interface\n\n## Technical Stack\n- **Mobile**: React Native + Expo for cross-platform development\n- **UI**: React Native Paper + React Native Elements\n- **State**: Redux Toolkit with Redux Persist\n- **Backend**: Node.js + Express + MongoDB + Redis\n- **Maps**: React Native Maps + Expo Location\n\n## Current Status\n**60% Complete** - Core features and family groups implemented, working on advanced consensus features.	/uploads/project/family-dinner-recommendation-app-1752285775527-picsumphotos-1.jpg	{"React Native",Expo,Node.js,MongoDB,Redis}	\N	https://github.com/username/family-dinner-recommendation	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:03:54.854767	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
741321c1-4646-4d01-9499-665965facf0a	Roku Midas Touch	roku-midas-touch	Roku channel development platform with content management, analytics, and monetization tools for streaming content creators.	# Roku Midas Touch\n\n## Project Overview\nA comprehensive Roku channel development platform designed to help content creators build, manage, and monetize streaming channels with advanced analytics and content management tools.\n\n## Key Features\n- **Channel Builder**: Visual channel creation with templates\n- **Content Management**: Upload, organize, and schedule content\n- **Analytics Dashboard**: Comprehensive viewership and performance analytics\n- **Monetization**: Ad integration and subscription management\n- **Multi-Channel**: Manage multiple Roku channels from one platform\n\n## Technical Stack\n- **Frontend**: React + TypeScript + Material-UI\n- **Backend**: Node.js + Express + PostgreSQL\n- **Roku Development**: BrightScript + SceneGraph\n- **Video Processing**: FFmpeg for video optimization\n- **Analytics**: Custom analytics engine\n\n## Current Status\n**55% Complete** - Core channel building features implemented, working on analytics and monetization.	/uploads/project/roku-midas-touch-1752285712376-picsumphotos-1.jpg	{React,TypeScript,Node.js,BrightScript,PostgreSQL,FFmpeg}	\N	https://github.com/username/roku-midas-touch	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:53.969867	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
3afe35ab-be75-4018-93bc-31225db69ec9	PRPG Game App	prpg-game-app	Progressive RPG game application with character development, quest systems, and multiplayer features for mobile and web platforms.	# PRPG Game App\n\n## Project Overview\nA Progressive RPG game application featuring character development, quest systems, and multiplayer features designed for both mobile and web platforms with modern gaming mechanics.\n\n## Key Features\n- **Character Development**: Deep character progression and customization\n- **Quest Systems**: Dynamic quest generation and storyline progression\n- **Multiplayer Features**: Real-time multiplayer battles and cooperation\n- **Cross-Platform**: Seamless gameplay across mobile and web\n- **Social Features**: Guild systems and player interaction\n\n## Technical Stack\n- **Frontend**: React + TypeScript + Phaser.js\n- **Mobile**: React Native + Expo\n- **Backend**: Node.js + Express + WebSocket\n- **Database**: PostgreSQL + Redis\n- **Game Engine**: Phaser.js for web, custom engine for mobile\n\n## Current Status\n**30% Complete** - Core game mechanics implemented, working on character and quest systems.	/uploads/project/prpg-game-app-1752285726068-picsumphotos-1.jpg	{React,"React Native",Phaser.js,Node.js,PostgreSQL,WebSocket}	\N	https://github.com/username/prpg-game-app	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:53.750249	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
5ab59417-817a-4299-aa85-87c81b940f68	Price Scraper Test	price-scraper-test	Advanced price monitoring and scraping tool with automated alerts, historical tracking, and comprehensive market analysis.	# Price Scraper Test\n\n## Project Overview\nAn advanced price monitoring and scraping tool designed to track product prices across multiple retailers with automated alerts, historical tracking, and comprehensive market analysis capabilities.\n\n## Key Features\n- **Multi-Site Scraping**: Monitor prices across multiple ecommerce platforms\n- **Automated Alerts**: Price drop notifications and threshold alerts\n- **Historical Tracking**: Long-term price trend analysis and visualization\n- **Market Analysis**: Comprehensive market research and comparison tools\n- **API Integration**: RESTful API for external integrations\n\n## Technical Stack\n- **Backend**: Python + Flask + BeautifulSoup + Scrapy\n- **Frontend**: React + TypeScript + Chart.js\n- **Database**: PostgreSQL + Redis for caching\n- **Scheduling**: Celery for background tasks\n- **Monitoring**: Custom monitoring and alerting system\n\n## Current Status\n**40% Complete** - Core scraping functionality implemented, working on analysis features.	/uploads/project/price-scraper-test-1752285736570-picsumphotos-1.jpg	{Python,Flask,React,BeautifulSoup,PostgreSQL,Celery}	\N	https://github.com/username/price-sraper-test	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:53.639614	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
15d289b6-620a-4a43-af7e-8c31cf3ef7e9	Grocery Management App	grocery-management-app	Cross-platform grocery management application with smart shopping lists, recipe suggestions, budget tracking, and family sharing capabilities.	# Grocery Management App\n\n## Project Overview\nA cross-platform grocery management application built with Electron and React Native, featuring smart shopping lists, recipe suggestions, budget tracking, and family sharing capabilities.\n\n## Key Features\n- **Smart Shopping Lists**: AI-powered list generation and optimization\n- **Recipe Integration**: Recipe suggestions based on available ingredients\n- **Budget Tracking**: Comprehensive expense tracking and budget management\n- **Family Sharing**: Multi-user support with synchronized lists\n- **Cross-Platform**: Desktop and mobile versions\n\n## Technical Stack\n- **Desktop**: Electron + React + TypeScript\n- **Mobile**: React Native + TypeScript\n- **Backend**: Node.js + Express + PostgreSQL\n- **AI**: OpenAI API for recipe suggestions\n- **State Management**: Redux Toolkit\n\n## Current Status\n**55% Complete** - Core features implemented, working on advanced AI features and mobile optimization.	/uploads/project/grocery-management-app-1752285671525-picsumphotos-1.jpg	{Electron,"React Native",TypeScript,PostgreSQL,OpenAI}	\N	https://github.com/username/grocery-app	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:54.51947	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
0b41313d-7991-44e0-bf9e-59ef2b31d91a	Syll - Syllabus Management System	syll-syllabus-management-system	Comprehensive syllabus management system for educational institutions with course planning, progress tracking, and student engagement tools.	# Syll - Syllabus Management System\n\n## Project Overview\nA comprehensive syllabus management system designed for educational institutions to create, manage, and track academic curricula with course planning, progress tracking, and student engagement tools.\n\n## Key Features\n- **Curriculum Builder**: Visual course and syllabus creation tools\n- **Progress Tracking**: Student progress monitoring and analytics\n- **Assignment Management**: Create, distribute, and grade assignments\n- **Communication Tools**: Announcements, messaging, and discussion forums\n- **Resource Library**: Course materials and document management\n\n## Technical Stack\n- **Frontend**: React + TypeScript + Material-UI\n- **Backend**: Node.js + Express + PostgreSQL\n- **Authentication**: JWT with role-based access\n- **File Storage**: AWS S3 for course materials\n- **Real-time**: Socket.io for live updates\n\n## Current Status\n**35% Complete** - Core syllabus management implemented, working on student tracking and communication features.	/uploads/project/syll-syllabus-management-system-1752285697062-picsumphotos-1.jpg	{React,TypeScript,Node.js,PostgreSQL,JWT,"AWS S3"}	\N	https://github.com/username/syll	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:54.188278	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
ddb73a5b-82ef-49c3-8f4e-40427e663306	AI Voice-Over Studio	ai-voice-over-studio	Cutting-edge voice cloning and generation studio utilizing 2025's most advanced AI voice technologies for professional voice-over production.	# AI Voice-Over Studio\n\n## Project Overview\nA cutting-edge voice cloning and generation studio utilizing 2025's most advanced AI voice technologies for professional voice-over production with real-time processing and professional audio tools.\n\n## Key Features\n- **Advanced Voice Cloning**: 2025 cutting-edge AI voice cloning technology\n- **Real-time Processing**: Live voice generation and modification\n- **Professional Audio Tools**: Comprehensive audio editing and effects\n- **Multiple Voice Models**: Various AI voice generation models\n- **Export Options**: Multiple audio formats and quality settings\n\n## Technical Stack\n- **Frontend**: Next.js + TypeScript + TailwindCSS + Shadcn/ui\n- **Backend**: Python + FastAPI + PyTorch + TensorFlow\n- **AI Models**: Latest 2025 voice cloning models\n- **Audio Processing**: FFmpeg + Web Audio API\n- **Real-time**: WebRTC for real-time audio streaming\n\n## Current Status\n**0% Complete** - Project in planning phase with comprehensive tech stack defined for 2025 technologies.	/uploads/project/ai-voice-over-studio-1752285631558-picsumphotos-1.jpg	{Next.js,Python,FastAPI,PyTorch,TensorFlow,WebRTC}	\N	https://github.com/username/ai-voice-over	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:55.071423	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
78f8ef89-ad6e-40b6-97b0-be0ea603321f	Real Estate Business Platform	real-estate-business-platform	Comprehensive self-hosted platform for real estate professionals with listing management, CRM, lead management, document generation, and marketing automation.	# Real Estate Business Platform\n\n## Project Overview\nA comprehensive self-hosted platform designed for real estate professionals to manage listings, clients, leads, contracts, and marketing campaigns with a public-facing website and powerful admin dashboard.\n\n## Key Features\n- **Public Website**: Property listings with advanced search and virtual tours\n- **CRM System**: Client profiles, communication history, and task management\n- **Lead Management**: Pipeline view with automated nurturing campaigns\n- **Document Management**: Template library with digital signatures\n- **Marketing Integration**: Social media automation and email campaigns\n\n## Technical Stack\n- **Frontend**: Next.js + TypeScript + TailwindCSS + Shadcn/ui\n- **Backend**: Node.js + Express + PostgreSQL + Redis\n- **Authentication**: Passport.js with JWT\n- **Storage**: MinIO for self-hosted file storage\n- **Email**: Nodemailer with self-hosted SMTP\n\n## Current Status\n**0% Complete** - Project in planning phase with comprehensive tech stack defined.	/uploads/project/real-estate-business-platform-1752285638147-picsumphotos-1.jpg	{Next.js,TypeScript,PostgreSQL,MinIO,Redis}	\N	https://github.com/username/real-estate-app	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:54.961706	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
4442ac4c-515f-4092-8f95-e834a9b81a92	Rental Property Manager	rental-property-manager	Comprehensive rental property management system with tenant management, rent collection, maintenance tracking, and financial reporting for property managers.	# Rental Property Manager\n\n## Project Overview\nA comprehensive rental property management system designed for property managers to handle all aspects of rental operations from tenant management to financial reporting.\n\n## Key Features\n- **Property Management**: CRUD operations with search and filtering\n- **Tenant Management**: Profiles, lease management, and communication\n- **Rent Collection**: Payment tracking with Stripe integration\n- **Maintenance System**: Work order management and scheduling\n- **Financial Reporting**: Income statements and balance sheets\n\n## Technical Stack\n- **Backend**: Node.js + Express.js + MongoDB\n- **Frontend**: Next.js 14 + Material-UI + Redux Toolkit\n- **Mobile**: React Native with React Native Paper\n- **Authentication**: Auth0 integration\n- **Payment**: Stripe API integration\n\n## Current Status\n**Phase 1 Partial** - Basic UI components implemented, authentication and payment integration pending.	/uploads/general/1cba08a1-2dec-4efd-b2aa-e8deb771517f.png	{Next.js,Node.js,MongoDB,"React Native",Stripe}			t	all	published	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:54.850047	2025-10-24 17:22:27.280629	\N	\N	2025-10-24 17:22:27.280629
3803537b-5b87-4b02-a0ea-9a713df6b5bc	Digital Planner Creator - Ecommerce Tool	digital-planner-creator-ecommerce-tool	A comprehensive digital planner creation and ecommerce integration tool that enables users to create, customize, and sell professional digital planners across multiple platforms.	# Digital Planner Creator\n\n## Project Overview\nBuilding a comprehensive digital planner creation and ecommerce integration tool that enables users to create, customize, and sell professional digital planners across multiple platforms.\n\n## Key Features\n- **Planner Design Engine**: Advanced PDF generation with ReportLab\n- **Seasonal Themes**: Interactive theme system with Pexels API integration\n- **Multi-View Support**: Yearly, monthly, weekly, and daily planner views\n- **Ecommerce Integration**: Etsy, Shopify, Creative Market APIs\n- **Template System**: Pre-built templates and custom design tools\n\n## Technical Stack\n- **Backend**: Python 3.7+ + Flask + ReportLab\n- **Frontend**: Next.js 14 + TypeScript + TailwindCSS\n- **Database**: PostgreSQL with Prisma ORM\n- **File Storage**: AWS S3 for digital assets\n- **APIs**: Pexels, Etsy, Shopify, Creative Market\n\n## Current Status\n**35% Complete** - Foundation complete, working on modern web architecture and user system.	/uploads/project/digital-planner-creator-ecommerce-tool-1752285656114-picsumphotos-1.jpg	{Python,Flask,Next.js,PostgreSQL,"AWS S3"}	\N	https://github.com/username/planner-app	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:54.740653	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
aaf9def0-616e-4b20-bba1-bd8ec404bdd0	AI Education Platform	ai-education-platform	Comprehensive AI-powered educational platform with personalized learning paths, interactive content, and real-time progress tracking.	## AI Education Platform\n\n### Project Overview\nA comprehensive AI-powered educational platform that revolutionizes online learning through personalized learning paths, interactive content, and intelligent progress tracking.\n\n### Key Features\n- **Personalized Learning Paths**: AI-driven curriculum adaptation based on individual learning styles and progress\n- **Interactive Content**: Multimedia lessons, quizzes, and hands-on exercises\n- **Real-time Progress Tracking**: Detailed analytics and performance insights\n- **Collaborative Learning**: Student forums, group projects, and peer-to-peer learning\n- **Instructor Dashboard**: Advanced tools for course creation and student management\n- **Mobile-First Design**: Responsive platform optimized for all devices\n\n### Technical Stack\n- **Frontend**: React.js, TypeScript, Tailwind CSS\n- **Backend**: Node.js, Express.js\n- **Database**: PostgreSQL\n- **AI/ML**: Python, TensorFlow, OpenAI API\n- **Authentication**: NextAuth.js\n- **Payment**: Stripe Integration\n- **Deployment**: Vercel, AWS\n\n### Development Status\n- **Phase 1**: User authentication and basic dashboard (100% Complete)\n- **Phase 2**: Course creation and content management (100% Complete)\n- **Phase 3**: AI-powered personalization engine (100% Complete)\n- **Phase 4**: Mobile optimization and performance (100% Complete)\n- **Phase 5**: Advanced analytics and reporting (100% Complete)\n\n### Success Metrics\n- User engagement rates\n- Course completion rates\n- Learning outcome improvements\n- Platform scalability metrics\n\nThis project represents a significant advancement in educational technology, combining modern web development with cutting-edge AI capabilities.	/uploads/project/ai-education-platform-1752285616679-picsumphotos-1.jpg	{React.js,TypeScript,Node.js,PostgreSQL,Python,TensorFlow,"OpenAI API",NextAuth.js,Stripe,"Tailwind CSS",Vercel,AWS}	\N	\N	f	all	draft	\N	\N	\N	2025-07-12 01:44:37.241	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
cd801756-024a-46c7-9bda-ee9080607b1b	Vinyl Graphics Ecommerce Platform	vinyl-graphics-ecommerce-platform	Self-hosted ecommerce platform for vinyl products with user-facing design tool, comprehensive search, cart/wishlist, and robust admin dashboard with analytics.	# Vinyl Graphics Ecommerce Platform\n\n## Project Overview\nA self-hosted ecommerce platform for selling premade and custom vinyl products (stickers, banners, decals, etc.) featuring a user-facing design tool and comprehensive management system.\n\n## Key Features\n- **Design Tool**: User-facing design interface with Fabric.js/Konva.js\n- **Product Catalog**: Advanced filtering and search with Meilisearch\n- **Ecommerce Core**: Cart, wishlist, and checkout with Stripe\n- **Admin Dashboard**: Product management and sales analytics\n- **Custom Design**: Real-time design tool for custom vinyl products\n\n## Technical Stack\n- **Frontend**: Next.js + TypeScript + TailwindCSS + Shadcn/ui\n- **Backend**: Node.js + Express + Prisma + PostgreSQL\n- **Design Tool**: Fabric.js + Konva.js for graphics editing\n- **Search**: Meilisearch for advanced product search\n- **Storage**: MinIO for file storage\n\n## Current Status\n**50% Complete** - Core development and admin dashboard in progress.	/uploads/project/vinyl-graphics-ecommerce-platform-1752285663950-picsumphotos-1.jpg	{Next.js,TypeScript,Fabric.js,PostgreSQL,Meilisearch}	\N	https://github.com/username/vinyl-graphics-ecommerce	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:54.630691	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
d37890d4-21ab-42d5-aceb-3ad84258d404	Unique Story Game	unique-story-game	Interactive storytelling game with branching narratives, character development, and user-generated content for immersive gaming experiences.	# Unique Story Game\n\n## Project Overview\nAn interactive storytelling game featuring branching narratives, character development, and user-generated content designed to create immersive and personalized gaming experiences.\n\n## Key Features\n- **Branching Narratives**: Multiple story paths and endings\n- **Character Development**: Deep character customization and progression\n- **User-Generated Content**: Tools for players to create their own stories\n- **Community Features**: Share stories and rate other players' content\n- **Multi-Platform**: Available on web, mobile, and desktop\n\n## Technical Stack\n- **Frontend**: React + TypeScript + Styled Components\n- **Mobile**: React Native + Expo\n- **Backend**: Node.js + Express + MongoDB\n- **Story Engine**: Custom narrative engine\n- **Real-time**: WebSocket for multiplayer features\n\n## Current Status\n**25% Complete** - Core story engine implemented, working on user interface and content creation tools.	/uploads/project/unique-story-game-1752285679002-picsumphotos-1.jpg	{React,"React Native",TypeScript,Node.js,MongoDB,WebSocket}	\N	https://github.com/username/unique-story-game	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:54.410175	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
97027f23-ad34-436e-ab0d-4658f8968b2e	Social Media Uploader	social-media-uploader	Multi-platform social media content uploader with scheduling, automation, and analytics for content creators and marketers.	# Social Media Uploader\n\n## Project Overview\nA comprehensive multi-platform social media content uploader designed for content creators and marketers to efficiently schedule, automate, and analyze their social media presence across multiple platforms.\n\n## Key Features\n- **Multi-Platform Support**: Upload to Instagram, Twitter, Facebook, LinkedIn, TikTok\n- **Content Scheduling**: Advanced scheduling with optimal posting times\n- **Bulk Upload**: Batch processing for multiple posts\n- **Analytics Integration**: Performance tracking and engagement metrics\n- **Content Templates**: Pre-designed templates for different platforms\n\n## Technical Stack\n- **Frontend**: Next.js + TypeScript + TailwindCSS\n- **Backend**: Node.js + Express + PostgreSQL\n- **APIs**: Social media platform APIs\n- **Scheduling**: Cron jobs with Redis queue\n- **Storage**: AWS S3 for media files\n\n## Current Status\n**70% Complete** - Core upload and scheduling features implemented, working on advanced analytics.	/uploads/project/social-media-uploader-1752285704860-picsumphotos-1.jpg	{Next.js,TypeScript,Node.js,PostgreSQL,"Social Media APIs","AWS S3"}	\N	https://github.com/username/social-media-uploader	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:54.07961	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
d2333c04-99e1-465c-9da2-2fbcc0567285	Rate My Rack	rate-my-rack	Community-driven rating platform for server racks and IT infrastructure with photo sharing, reviews, and technical specifications.	# Rate My Rack\n\n## Project Overview\nA community-driven rating platform designed for IT professionals to share, rate, and review server racks and IT infrastructure setups with photo sharing, technical specifications, and community feedback.\n\n## Key Features\n- **Photo Sharing**: Upload and share server rack photos\n- **Rating System**: Community-driven rating and review system\n- **Technical Specs**: Detailed hardware and configuration information\n- **Community Features**: Comments, favorites, and user profiles\n- **Search & Filter**: Advanced search by hardware, brand, and specifications\n\n## Technical Stack\n- **Frontend**: Next.js + TypeScript + TailwindCSS\n- **Backend**: Node.js + Express + PostgreSQL\n- **Image Storage**: AWS S3 + CloudFront\n- **Authentication**: NextAuth.js\n- **Search**: Elasticsearch for advanced search\n\n## Current Status\n**45% Complete** - Core platform implemented, working on advanced features and community tools.	/uploads/project/rate-my-rack-1752285719451-picsumphotos-1.jpg	{Next.js,TypeScript,Node.js,PostgreSQL,"AWS S3",Elasticsearch}	\N	https://github.com/username/ratemyrack	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:53.85924	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
39921fbf-76a1-4db8-be13-2d0fbfb49e4c	Group Chat International	group-chat-international	International group chat platform with real-time translation, cultural exchange features, and global community building tools.	# Group Chat International\n\n## Project Overview\nAn international group chat platform designed to connect people from different countries and cultures with real-time translation, cultural exchange features, and comprehensive community building tools.\n\n## Key Features\n- **Real-time Translation**: Instant message translation in multiple languages\n- **Cultural Exchange**: Features to promote cultural understanding and learning\n- **Group Management**: Advanced group creation and moderation tools\n- **Global Discovery**: Find and connect with people from specific countries or cultures\n- **Media Sharing**: Share photos, videos, and cultural content\n\n## Technical Stack\n- **Frontend**: React + TypeScript + Socket.io Client\n- **Backend**: Node.js + Express + Socket.io + PostgreSQL\n- **Translation**: Google Translate API + Custom translation services\n- **Real-time**: WebSocket for instant messaging\n- **Media**: Cloud storage for media sharing\n\n## Current Status\n**50% Complete** - Core chat features implemented, working on translation and cultural features.	/uploads/project/group-chat-international-1752285744415-picsumphotos-1.jpg	{React,TypeScript,Node.js,Socket.io,PostgreSQL,"Translation APIs"}	\N	https://github.com/username/group-chat-international	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:53.529087	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
ce582173-d094-4bba-9eb9-22cd5ee35622	Sports Analytics Desktop	sports-analytics-desktop	AI-powered desktop application for sports analytics with machine learning predictions, real-time game tracking, and comprehensive performance analysis for NBA, NFL, and MLB.	# Sports Analytics Desktop\n\n## Project Overview\nSports Analytics Desktop is a comprehensive AI-powered desktop application that analyzes historical sports data, provides real-time game insights, and generates ML-based predictions for NBA, NFL, and MLB games.\n\n## Key Features\n- **AI/ML Prediction Engine**: Advanced machine learning models with confidence scoring\n- **Historical Data Analysis**: 12,500+ NBA games processed\n- **Real-time Game Tracking**: Live score updates and prediction adjustments\n- **Advanced Visualization**: Interactive charts and analytics dashboard\n- **Multi-league Support**: NBA, NFL, MLB with extensible architecture\n\n## Technical Stack\n- **Desktop**: Electron v27.3.11 with React + Next.js\n- **Database**: SQLite with Knex.js ORM\n- **ML/AI**: Python + scikit-learn + pandas + NumPy\n- **Visualization**: Recharts for data visualization\n- **Build**: Electron Builder for cross-platform packaging\n\n## Current Status\n**45% Complete** - Core foundation implemented, working on advanced analytics and AI features.	/uploads/project/sports-analytics-desktop-1752285782079-picsumphotos-1.jpg	{Electron,React,Python,SQLite,"Machine Learning"}	\N	https://github.com/username/sports-bet	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:03:54.74777	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
4722339f-29f8-4686-840c-ca50ffbc0f54	Trump Rants Website	trump-rants-website	Content aggregation platform featuring Trump-related content with community features, monetization systems, and comprehensive content management.	# Trump Rants Website\n\n## Project Overview\nA content aggregation platform featuring Trump-related content with community features, monetization systems, and comprehensive content management capabilities.\n\n## Key Features\n- **Content Aggregation**: Automated content collection and curation\n- **Community Features**: User comments, ratings, and discussions\n- **Monetization**: Multiple revenue streams and advertising\n- **Content Management**: Advanced CMS with moderation tools\n- **SEO Optimization**: Search engine optimization features\n\n## Technical Stack\n- **Frontend**: Next.js + TypeScript + TailwindCSS\n- **Backend**: Node.js + Express + PostgreSQL\n- **Content**: Automated content aggregation systems\n- **Monetization**: Stripe integration and ad management\n- **SEO**: Advanced SEO optimization tools\n\n## Current Status\n**90% Complete** - Core platform and monetization systems implemented, working on final features.	/uploads/project/trump-rants-website-1752285624217-picsumphotos-1.jpg	{Next.js,TypeScript,Node.js,PostgreSQL,Stripe}		https://github.com/username/trump-rant	f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:55.18099	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
3f09dc0d-2e1e-41de-aa91-9b6715855d08	Habit Builder - Intelligent Habit Tracking App	habit-builder-intelligent-habit-tracking-app	A self-hosted habit building application with intelligent coaching, realistic goal guidance, burnout prevention, and comprehensive progress tracking for building sustainable habits.	# Habit Builder Application\n\n## Project Overview\nA self-hosted habit building application designed to help users build and maintain healthy habits including walking, exercise, nutrition, hydration, education, and handy work skills.\n\n## Key Features\n- **Intelligent Habit Coaching**: AI-powered coaching algorithms with realistic goal guidance\n- **Burnout Prevention**: Adaptive difficulty and personalized guidance\n- **Progress Tracking**: Visual analytics with streak tracking and milestone celebrations\n- **Calendar Integration**: Scheduling with holiday and special day handling\n- **Notification System**: Web push notifications with PWA capabilities\n\n## Technical Stack\n- **Frontend**: Next.js 14 + TypeScript + TailwindCSS\n- **UI Components**: Shadcn/ui + Framer Motion\n- **Backend**: Node.js + Prisma ORM + PostgreSQL\n- **Cache**: Redis for sessions and caching\n- **Authentication**: NextAuth.js with bcrypt security\n\n## Current Status\n**89% Complete** - All core features implemented, only Docker deployment remaining.	/uploads/project/habit-builder-intelligent-habit-tracking-app-1752285820230-picsumphotos-1.jpg	{Next.js,TypeScript,PostgreSQL,Redis,PWA}			f	all	draft	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:03:54.204288	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
ce5d16c4-08ac-4428-9f6e-c7479e0dfcca	AI Date Night - Social Media Profile Analysis	ai-date-night-social-media-profile-analysis	AI-powered social media profile analysis and date planning application with intelligent question generation and multi-platform support.	# AI Date Night\n\n## Project Overview\nAI Date Night is a comprehensive platform designed to analyze social media profiles, generate personalized questions, and plan perfect dates based on user preferences. The application streamlines the process of understanding potential matches through social media integration, AI-driven profile analysis, and intelligent date planning to create meaningful connections.\n\n## Key Features\n- **Social Media Integration**: Connect with major platforms (Twitter, Instagram, Facebook, LinkedIn)\n- **AI Profile Building**: OpenAI integration for profile analysis and personality trait extraction\n- **Question Generation System**: Personalized question generation with context-aware follow-up questions\n- **Date Planning Engine**: Location services integration with activity recommendation system\n- **Multi-platform Support**: Web and mobile applications with shared architecture\n- **Messaging System**: Twilio integration with WebSocket communication\n\n## Technical Stack\n- **Frontend**: React + TypeScript + Redux Toolkit + Material UI\n- **Mobile**: React Native + Expo + TypeScript\n- **Backend**: Node.js + Express + PostgreSQL + Redis\n- **AI**: OpenAI API + LangChain\n- **Social Media**: Twitter, Instagram, Facebook, LinkedIn APIs\n- **Location**: Google Places API + Mapbox\n\n## Current Status\n**92% Complete** - Most features implemented, working on testing and deployment.	/uploads/project/ai-date-night-social-media-profile-analysis-1752285826870-picsumphotos-1.jpg	{React,"React Native",Node.js,PostgreSQL,OpenAI,"Social Media APIs"}			f	professional	draft	2025-07-16 12:00:00	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:03:54.091992	2025-10-23 18:41:04.2877	\N	\N	2025-10-23 18:41:04.2877
c7a57050-be63-46e8-98d7-a9d1a06e02a8	Weather Dashboard	weather-dashboard	A comprehensive weather application with real-time data, 7-day forecasts, and interactive maps. Features location-based weather alerts and customizable dashboard widgets.	# Weather Dashboard\r\n\r\n## Application Overview\r\nA modern weather application that provides comprehensive meteorological data with beautiful visualizations and interactive features. Perfect for both casual users and weather enthusiasts.\r\n\r\n## Features\r\n- **Real-time Weather Data**: Current conditions with minute-by-minute updates\r\n- **Extended Forecasts**: 7-day detailed weather predictions\r\n- **Interactive Maps**: Radar, satellite, and temperature overlays\r\n- **Location Services**: Automatic location detection and multiple location support\r\n- **Weather Alerts**: Push notifications for severe weather warnings\r\n- **Customizable Widgets**: Personalized dashboard with draggable components\r\n\r\n## Data Sources\r\nIntegrates with multiple weather APIs including OpenWeatherMap, WeatherAPI, and NOAA for the most accurate and comprehensive weather information available.\r\n\r\n## User Experience\r\n- **Responsive Design**: Optimized for desktop, tablet, and mobile\r\n- **Accessibility**: Full WCAG 2.1 compliance\r\n- **Performance**: <2 second load times with progressive loading\r\n- **Offline Mode**: Cached data for offline viewing\r\n- **Internationalization**: Support for 15+ languages\r\n\r\n## Technical Highlights\r\n- Progressive Web App (PWA) capabilities\r\n- Service Worker for offline functionality\r\n- WebGL-powered map visualizations\r\n- Real-time data streaming with WebSocket connections	/uploads/general/0a7c3cb7-a0a3-40fd-bd41-19028817989f.png	{React,TypeScript,WebGL,PWA,"Service Workers",Chart.js,Leaflet}			t	all	published	\N	2025-04-25 18:43:35.200917	\N	2025-07-09 18:43:35.200917	2025-10-24 17:22:51.575872	\N	\N	2025-10-24 17:22:51.575872
2af208e0-19d4-49a8-93d3-09493b853117	T-Shirt 2.0	t-shirt-2-0	Advanced t-shirt design and customization platform with AI-powered design suggestions, print-on-demand integration, and marketplace features.	# T-Shirt 2.0\n\n## Project Overview\nAn advanced t-shirt design and customization platform featuring AI-powered design suggestions, print-on-demand integration, and comprehensive marketplace features for designers and customers.\n\n## Key Features\n- **AI Design Assistant**: AI-powered design suggestions and customization\n- **Visual Editor**: Advanced design tools with layers and effects\n- **Print Integration**: Direct integration with print-on-demand services\n- **Marketplace**: Platform for designers to sell custom designs\n- **3D Preview**: Realistic 3D preview of designs on t-shirts\n\n## Technical Stack\n- **Frontend**: Next.js + TypeScript + TailwindCSS\n- **Design Editor**: Fabric.js + Konva.js\n- **Backend**: Node.js + Express + PostgreSQL\n- **AI**: OpenAI API for design suggestions\n- **Print API**: Integration with print-on-demand services\n\n## Current Status\n**50% Complete** - Core design tools implemented, working on AI features and marketplace.	/uploads/general/a3738b1c-4e32-42c4-8de3-f6b9bc447307.jpg	{Next.js,TypeScript,Fabric.js,Node.js,PostgreSQL,OpenAI}			t	all	published	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:06:54.299941	2025-10-24 17:23:16.014898	\N	\N	2025-10-24 17:23:16.014898
8ecea50b-0908-4430-ac07-93f224563ed9	AI Education Platform - Comprehensive Learning Hub	ai-education-platform-comprehensive-learning-hub	A comprehensive AI education website with 74 professional courses covering AI fundamentals, development mastery, no-code platforms, and advanced integration. Features enterprise-grade SSO, white-label solutions, and monetization systems.	# AI Education Platform\n\n## Project Overview\nA comprehensive AI education website designed to teach effective use of cutting-edge AI technologies for application development. The platform provides structured learning paths with hands-on exercises, knowledge checks, and practical video tutorials covering the complete spectrum of AI tools available in 2025.\n\n## Key Features\n- **74 Professional Courses** across 4 learning paths\n- **Enterprise-Grade Features** including SSO and white-label solutions\n- **Advanced Analytics** and business intelligence dashboard\n- **Marketing Automation** with email campaigns and user segmentation\n- **Performance Optimization** with PWA capabilities and offline learning\n\n## Technical Stack\n- **Frontend**: Next.js 14 + TypeScript + TailwindCSS\n- **Backend**: Node.js + Prisma ORM + PostgreSQL\n- **Authentication**: NextAuth.js with enterprise SSO\n- **Cache**: Redis for performance optimization\n- **Analytics**: Comprehensive business intelligence system\n\n## Current Status\n**100% Complete** - Enterprise-ready and production-deployment-ready with all features implemented including SSO, white-label solutions, usage limits, referral system, and advanced analytics.	/uploads/general/20c06eaf-5e0a-4c39-88e9-059afe73b3f3.jpg	{Next.js,TypeScript,PostgreSQL,Redis,"Enterprise SSO"}			t	all	published	\N	\N	ff43d28c-ca1d-4f4c-a482-739dea31875b	2025-07-11 23:03:53.872707	2025-10-24 17:23:44.279258	\N	\N	2025-10-24 17:23:44.279258
\.


--
-- TOC entry 3959 (class 0 OID 24832)
-- Dependencies: 237
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, display_name, description, permissions, is_system, created_at, updated_at) FROM stdin;
c98c68dc-95d1-4d58-a54a-103f84ee7ede	subscriber	Subscriber	Basic read-only access	{read_posts}	t	2025-07-09 17:19:49.313116	2025-07-12 15:05:47.743599
a8fe39bb-4027-4e43-9260-b5582542ba32	author	Author	Can create and edit their own content	{read_posts,write_posts,edit_posts}	t	2025-07-09 17:19:49.313116	2025-07-12 15:05:47.743599
61330818-9cf0-401f-85ca-1e5954a76e89	editor	Editor	Can manage content and moderate posts	{read_posts,write_posts,edit_posts,delete_posts,manage_media,manage_comments}	t	2025-07-09 17:19:49.313116	2025-07-12 15:05:47.743599
a80cddfd-153d-4f66-b6ef-c92ae9f39ede	admin	Administrator	Full system access	{system_admin,manage_users,manage_settings,manage_roles,view_analytics,manage_media,edit_posts,delete_posts,write_posts,read_posts}	t	2025-07-09 17:19:49.313116	2025-07-12 15:05:47.743599
\.


--
-- TOC entry 3960 (class 0 OID 24841)
-- Dependencies: 238
-- Data for Name: security_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.security_logs (id, user_id, user_email, action, details, ip_address, user_agent, status, created_at) FROM stdin;
\.


--
-- TOC entry 3961 (class 0 OID 24850)
-- Dependencies: 239
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, session_token, user_id, expires, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3962 (class 0 OID 24856)
-- Dependencies: 240
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.site_settings (id, setting_key, setting_value, updated_at) FROM stdin;
f8454030-fa2a-43d0-99da-2a7e10156b7e	logoUrl	/images/006618bf-8f9b-4546-8eda-1c377c97a93c.svg	2025-07-12 14:37:39.036682
1c3afedc-341b-4eea-bdf8-a3ffd0e039bb	logoText	Jonathan L Keck	2025-07-12 14:37:39.039947
a38751da-71ea-405a-826b-1ead651f35d4	footerText	Built with more than a little help from AI	2025-07-12 14:37:39.04221
29f90088-c0d5-4a7d-8a33-3915f7fa01f1	bioText	A Jack-of-All-Trades and a master of some, or one, well maybe. A Teacher, a Learner, a creator of things.	2025-07-12 14:37:39.044812
ab3f4434-4d2a-45b9-b468-86abb27a77ac	navbarStyle	default	2025-07-12 14:37:39.047316
2e3725fd-0c65-4f67-88a6-ead8913de60e	navbarLinks	[{"label":"Home","url":"/","isExternal":false},{"label":"About","url":"/about","isExternal":false},{"label":"Projects","url":"/projects","isExternal":false},{"label":"Blog","url":"/blog","isExternal":false},{"label":"Contact","url":"/contact","isExternal":false}]	2025-07-12 14:37:39.049821
d24adef0-e4a8-48f0-a099-64309a88b45f	sendgrid_api_key		2025-07-12 14:37:39.052103
c244ca4b-56a2-4120-9469-d5818e8cbdc4	sendgrid_from_email	noreply@yoursite.com	2025-07-12 14:37:39.054241
bedd0cd3-a582-4171-9abd-251e18d36d5a	sendgrid_from_name	Your Site Newsletter	2025-07-12 14:37:39.056492
c1fa7892-c074-4224-b94e-20e7ccde6d92	sendgrid_reply_to	contact@yoursite.com	2025-07-12 14:37:39.058681
5920261a-73e2-424d-9e53-75f9d1b96298	newsletter_enabled	true	2025-07-12 14:37:39.061088
c7fa444c-3bf5-4d8e-a73b-4ada9695f8a8	newsletter_double_optin	false	2025-07-12 14:37:39.063329
\.


--
-- TOC entry 3963 (class 0 OID 24863)
-- Dependencies: 241
-- Data for Name: user_2fa_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_2fa_settings (id, user_id, is_enabled, secret_key, backup_codes, last_used_at, enabled_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3964 (class 0 OID 24872)
-- Dependencies: 242
-- Data for Name: user_access_levels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_access_levels (id, user_id, email, has_professional_access, has_personal_access, granted_at, granted_by, is_active, notes) FROM stdin;
7b61be22-60a6-4060-be53-518994c4a6ce	\N	admin@example.com	t	t	2025-07-09 21:10:18.167984	\N	t	Admin user with full access
a8a36f3b-88e7-408f-8f88-5536dd939f17	f2ebffd1-9db4-4dcf-b75f-659c0a7cc1a0	test@example.com	f	t	2025-07-12 13:05:58.606278	ff43d28c-ca1d-4f4c-a482-739dea31875b	t	User created by admin with subscriber role
\.


--
-- TOC entry 3965 (class 0 OID 24882)
-- Dependencies: 243
-- Data for Name: user_activity_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_activity_log (id, user_id, action, description, performed_by, ip_address, created_at) FROM stdin;
6ba37868-109d-4178-adc8-fc1f5f2fad26	f2ebffd1-9db4-4dcf-b75f-659c0a7cc1a0	user_created	User account created by admin with role: subscriber	admin@example.com	127.0.0.1	2025-07-12 13:05:58.60947
97931738-cc1b-4e1b-b250-1526c7055851	f2ebffd1-9db4-4dcf-b75f-659c0a7cc1a0	user_updated	User profile updated by admin. Fields: name = $1, email = $2, status = $3, updated_at = $4	ff43d28c-ca1d-4f4c-a482-739dea31875b	\N	2025-07-12 21:38:33.076464
17715203-7b45-46bf-8a73-1e9ce72d07c9	f2ebffd1-9db4-4dcf-b75f-659c0a7cc1a0	user_updated	User profile updated by admin. Fields: name = $1, email = $2, status = $3, updated_at = $4	ff43d28c-ca1d-4f4c-a482-739dea31875b	\N	2025-07-12 21:39:02.602865
b12cfc78-e0b5-428f-9d22-a93dd414bf5a	f2ebffd1-9db4-4dcf-b75f-659c0a7cc1a0	user_updated	User profile updated by admin. Fields: name = $1, email = $2, status = $3, updated_at = $4	ff43d28c-ca1d-4f4c-a482-739dea31875b	\N	2025-07-12 23:44:53.669864
bff47156-e45c-44b0-afac-029aa2b724ee	f2ebffd1-9db4-4dcf-b75f-659c0a7cc1a0	user_updated	User profile updated by admin. Fields: name = $1, email = $2, status = $3, updated_at = $4	ff43d28c-ca1d-4f4c-a482-739dea31875b	\N	2025-07-15 18:56:11.449919
\.


--
-- TOC entry 3966 (class 0 OID 24889)
-- Dependencies: 244
-- Data for Name: user_login_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_login_sessions (id, user_id, session_token, device_info, ip_address, location, is_current, last_activity, created_at, expires_at) FROM stdin;
\.


--
-- TOC entry 3967 (class 0 OID 24898)
-- Dependencies: 245
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_permissions (id, user_id, permission_name, granted_at, granted_by, is_active) FROM stdin;
\.


--
-- TOC entry 3968 (class 0 OID 24904)
-- Dependencies: 246
-- Data for Name: user_role_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_role_history (id, user_id, old_role, new_role, changed_by, changed_at, reason) FROM stdin;
\.


--
-- TOC entry 3969 (class 0 OID 24911)
-- Dependencies: 247
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, password_hash, role, email_verified, created_at, updated_at, last_login, login_attempts, locked_until, status, profile_image, preferences) FROM stdin;
ff43d28c-ca1d-4f4c-a482-739dea31875b	Admin User	admin@example.com	$2b$12$UqFUl/TS0LtDW73ndlas8OZ/c30WoxlV8xtNu9kslpNgeK.Ydlh2y	admin	t	2025-07-09 21:10:18.159724	2025-07-09 21:10:18.159724	\N	0	\N	active	\N	{}
f2ebffd1-9db4-4dcf-b75f-659c0a7cc1a0	test	test@example.com	$2b$12$U/DXXoZWPmrf82Z0GSA9De1h9pxo6Zehv5ibK33KMcOwjIPzmpgBe	subscriber	t	2025-07-12 13:05:58.603054	2025-07-15 18:56:11.443	\N	0	\N	active	\N	{}
\.


--
-- TOC entry 3970 (class 0 OID 24926)
-- Dependencies: 248
-- Data for Name: verification_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verification_tokens (id, identifier, token, expires, created_at) FROM stdin;
\.


--
-- TOC entry 3979 (class 0 OID 0)
-- Dependencies: 226
-- Name: media_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.media_folders_id_seq', 1, false);


--
-- TOC entry 3589 (class 2606 OID 24940)
-- Name: access_requests access_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_requests
    ADD CONSTRAINT access_requests_pkey PRIMARY KEY (id);


--
-- TOC entry 3593 (class 2606 OID 24942)
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 3597 (class 2606 OID 24944)
-- Name: bulk_operations_log bulk_operations_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bulk_operations_log
    ADD CONSTRAINT bulk_operations_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3600 (class 2606 OID 24946)
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- TOC entry 3602 (class 2606 OID 24948)
-- Name: categories categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_key UNIQUE (slug);


--
-- TOC entry 3605 (class 2606 OID 24950)
-- Name: content_collaborators content_collaborators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_collaborators
    ADD CONSTRAINT content_collaborators_pkey PRIMARY KEY (id);


--
-- TOC entry 3609 (class 2606 OID 24952)
-- Name: content_comments content_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_comments
    ADD CONSTRAINT content_comments_pkey PRIMARY KEY (id);


--
-- TOC entry 3612 (class 2606 OID 24954)
-- Name: content_drafts content_drafts_content_type_content_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_drafts
    ADD CONSTRAINT content_drafts_content_type_content_id_key UNIQUE (content_type, content_id);


--
-- TOC entry 3614 (class 2606 OID 24956)
-- Name: content_drafts content_drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_drafts
    ADD CONSTRAINT content_drafts_pkey PRIMARY KEY (id);


--
-- TOC entry 3620 (class 2606 OID 24958)
-- Name: content_templates content_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_templates
    ADD CONSTRAINT content_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 3622 (class 2606 OID 24960)
-- Name: content_versions content_versions_content_id_version_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_versions
    ADD CONSTRAINT content_versions_content_id_version_number_key UNIQUE (content_id, version_number);


--
-- TOC entry 3624 (class 2606 OID 24962)
-- Name: content_versions content_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_versions
    ADD CONSTRAINT content_versions_pkey PRIMARY KEY (id);


--
-- TOC entry 3632 (class 2606 OID 24964)
-- Name: media_files media_files_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_pkey PRIMARY KEY (id);


--
-- TOC entry 3635 (class 2606 OID 24966)
-- Name: media_folders media_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_folders
    ADD CONSTRAINT media_folders_pkey PRIMARY KEY (id);


--
-- TOC entry 3641 (class 2606 OID 24968)
-- Name: newsletter_analytics newsletter_analytics_campaign_id_subscriber_id_event_type_c_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_analytics
    ADD CONSTRAINT newsletter_analytics_campaign_id_subscriber_id_event_type_c_key UNIQUE (campaign_id, subscriber_id, event_type, created_at);


--
-- TOC entry 3643 (class 2606 OID 24970)
-- Name: newsletter_analytics newsletter_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_analytics
    ADD CONSTRAINT newsletter_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 3647 (class 2606 OID 24972)
-- Name: newsletter_automation_rules newsletter_automation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_automation_rules
    ADD CONSTRAINT newsletter_automation_rules_pkey PRIMARY KEY (id);


--
-- TOC entry 3652 (class 2606 OID 24974)
-- Name: newsletter_campaigns newsletter_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_campaigns
    ADD CONSTRAINT newsletter_campaigns_pkey PRIMARY KEY (id);


--
-- TOC entry 3654 (class 2606 OID 24976)
-- Name: newsletter_campaigns newsletter_campaigns_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_campaigns
    ADD CONSTRAINT newsletter_campaigns_slug_key UNIQUE (slug);


--
-- TOC entry 3656 (class 2606 OID 24978)
-- Name: newsletter_content newsletter_content_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_content
    ADD CONSTRAINT newsletter_content_pkey PRIMARY KEY (id);


--
-- TOC entry 3661 (class 2606 OID 24980)
-- Name: newsletter_subscribers newsletter_subscribers_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_subscribers
    ADD CONSTRAINT newsletter_subscribers_email_key UNIQUE (email);


--
-- TOC entry 3663 (class 2606 OID 24982)
-- Name: newsletter_subscribers newsletter_subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_subscribers
    ADD CONSTRAINT newsletter_subscribers_pkey PRIMARY KEY (id);


--
-- TOC entry 3665 (class 2606 OID 24984)
-- Name: newsletter_templates newsletter_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_templates
    ADD CONSTRAINT newsletter_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 3668 (class 2606 OID 24986)
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- TOC entry 3670 (class 2606 OID 24988)
-- Name: pages pages_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key UNIQUE (slug);


--
-- TOC entry 3678 (class 2606 OID 24990)
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- TOC entry 3680 (class 2606 OID 24992)
-- Name: posts posts_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_slug_key UNIQUE (slug);


--
-- TOC entry 3683 (class 2606 OID 24994)
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- TOC entry 3690 (class 2606 OID 24996)
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- TOC entry 3692 (class 2606 OID 24998)
-- Name: projects projects_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_slug_key UNIQUE (slug);


--
-- TOC entry 3694 (class 2606 OID 25000)
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- TOC entry 3696 (class 2606 OID 25002)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 3700 (class 2606 OID 25004)
-- Name: security_logs security_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_logs
    ADD CONSTRAINT security_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3704 (class 2606 OID 25006)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3706 (class 2606 OID 25008)
-- Name: sessions sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_session_token_key UNIQUE (session_token);


--
-- TOC entry 3708 (class 2606 OID 25010)
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 3710 (class 2606 OID 25012)
-- Name: site_settings site_settings_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_setting_key_key UNIQUE (setting_key);


--
-- TOC entry 3712 (class 2606 OID 25014)
-- Name: user_2fa_settings user_2fa_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_2fa_settings
    ADD CONSTRAINT user_2fa_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 3714 (class 2606 OID 25016)
-- Name: user_2fa_settings user_2fa_settings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_2fa_settings
    ADD CONSTRAINT user_2fa_settings_user_id_key UNIQUE (user_id);


--
-- TOC entry 3719 (class 2606 OID 25018)
-- Name: user_access_levels user_access_levels_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_access_levels
    ADD CONSTRAINT user_access_levels_email_key UNIQUE (email);


--
-- TOC entry 3721 (class 2606 OID 25020)
-- Name: user_access_levels user_access_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_access_levels
    ADD CONSTRAINT user_access_levels_pkey PRIMARY KEY (id);


--
-- TOC entry 3726 (class 2606 OID 25022)
-- Name: user_activity_log user_activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT user_activity_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3730 (class 2606 OID 25024)
-- Name: user_login_sessions user_login_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_login_sessions
    ADD CONSTRAINT user_login_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3734 (class 2606 OID 25026)
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3736 (class 2606 OID 25028)
-- Name: user_permissions user_permissions_user_id_permission_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_id_permission_name_key UNIQUE (user_id, permission_name);


--
-- TOC entry 3739 (class 2606 OID 25030)
-- Name: user_role_history user_role_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_role_history
    ADD CONSTRAINT user_role_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3741 (class 2606 OID 25032)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3743 (class 2606 OID 25034)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3746 (class 2606 OID 25036)
-- Name: verification_tokens verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_tokens
    ADD CONSTRAINT verification_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3748 (class 2606 OID 25038)
-- Name: verification_tokens verification_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_tokens
    ADD CONSTRAINT verification_tokens_token_key UNIQUE (token);


--
-- TOC entry 3590 (class 1259 OID 25039)
-- Name: idx_access_requests_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_access_requests_email ON public.access_requests USING btree (email);


--
-- TOC entry 3591 (class 1259 OID 25040)
-- Name: idx_access_requests_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_access_requests_status ON public.access_requests USING btree (status);


--
-- TOC entry 3594 (class 1259 OID 25041)
-- Name: idx_accounts_provider; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_accounts_provider ON public.accounts USING btree (provider, provider_account_id);


--
-- TOC entry 3595 (class 1259 OID 25042)
-- Name: idx_accounts_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_accounts_user_id ON public.accounts USING btree (user_id);


--
-- TOC entry 3598 (class 1259 OID 25043)
-- Name: idx_bulk_operations_log_performed_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bulk_operations_log_performed_by ON public.bulk_operations_log USING btree (performed_by);


--
-- TOC entry 3603 (class 1259 OID 25044)
-- Name: idx_categories_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_categories_slug ON public.categories USING btree (slug);


--
-- TOC entry 3606 (class 1259 OID 25045)
-- Name: idx_content_collaborators_content_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_collaborators_content_id ON public.content_collaborators USING btree (content_id);


--
-- TOC entry 3607 (class 1259 OID 25046)
-- Name: idx_content_collaborators_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_collaborators_user_id ON public.content_collaborators USING btree (user_id);


--
-- TOC entry 3610 (class 1259 OID 25047)
-- Name: idx_content_comments_content_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_comments_content_id ON public.content_comments USING btree (content_id);


--
-- TOC entry 3615 (class 1259 OID 25048)
-- Name: idx_content_drafts_content_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_drafts_content_id ON public.content_drafts USING btree (content_id);


--
-- TOC entry 3616 (class 1259 OID 25049)
-- Name: idx_content_drafts_created_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_drafts_created_by ON public.content_drafts USING btree (created_by);


--
-- TOC entry 3617 (class 1259 OID 25050)
-- Name: idx_content_drafts_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_drafts_type ON public.content_drafts USING btree (content_type);


--
-- TOC entry 3618 (class 1259 OID 25051)
-- Name: idx_content_drafts_updated_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_drafts_updated_at ON public.content_drafts USING btree (updated_at);


--
-- TOC entry 3625 (class 1259 OID 25052)
-- Name: idx_content_versions_content_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_versions_content_id ON public.content_versions USING btree (content_id);


--
-- TOC entry 3626 (class 1259 OID 25053)
-- Name: idx_content_versions_content_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_versions_content_type ON public.content_versions USING btree (content_type);


--
-- TOC entry 3627 (class 1259 OID 25054)
-- Name: idx_media_files_folder; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_media_files_folder ON public.media_files USING btree (folder);


--
-- TOC entry 3628 (class 1259 OID 25055)
-- Name: idx_media_files_starred; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_media_files_starred ON public.media_files USING btree (starred);


--
-- TOC entry 3629 (class 1259 OID 25056)
-- Name: idx_media_files_tags; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_media_files_tags ON public.media_files USING gin (tags);


--
-- TOC entry 3630 (class 1259 OID 25057)
-- Name: idx_media_files_updated_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_media_files_updated_at ON public.media_files USING btree (updated_at);


--
-- TOC entry 3633 (class 1259 OID 25058)
-- Name: idx_media_folders_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_media_folders_parent ON public.media_folders USING btree (parent_id);


--
-- TOC entry 3636 (class 1259 OID 25059)
-- Name: idx_newsletter_analytics_campaign; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_newsletter_analytics_campaign ON public.newsletter_analytics USING btree (campaign_id);


--
-- TOC entry 3637 (class 1259 OID 25060)
-- Name: idx_newsletter_analytics_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_newsletter_analytics_created_at ON public.newsletter_analytics USING btree (created_at);


--
-- TOC entry 3638 (class 1259 OID 25061)
-- Name: idx_newsletter_analytics_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_newsletter_analytics_event_type ON public.newsletter_analytics USING btree (event_type);


--
-- TOC entry 3639 (class 1259 OID 25062)
-- Name: idx_newsletter_analytics_subscriber; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_newsletter_analytics_subscriber ON public.newsletter_analytics USING btree (subscriber_id);


--
-- TOC entry 3644 (class 1259 OID 25063)
-- Name: idx_newsletter_automation_rules_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_newsletter_automation_rules_active ON public.newsletter_automation_rules USING btree (is_active);


--
-- TOC entry 3645 (class 1259 OID 25064)
-- Name: idx_newsletter_automation_rules_next_run; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_newsletter_automation_rules_next_run ON public.newsletter_automation_rules USING btree (next_run_at);


--
-- TOC entry 3648 (class 1259 OID 25065)
-- Name: idx_newsletter_campaigns_scheduled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_newsletter_campaigns_scheduled ON public.newsletter_campaigns USING btree (scheduled_send_at);


--
-- TOC entry 3649 (class 1259 OID 25066)
-- Name: idx_newsletter_campaigns_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_newsletter_campaigns_status ON public.newsletter_campaigns USING btree (status);


--
-- TOC entry 3650 (class 1259 OID 25067)
-- Name: idx_newsletter_campaigns_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_newsletter_campaigns_type ON public.newsletter_campaigns USING btree (type);


--
-- TOC entry 3657 (class 1259 OID 25068)
-- Name: idx_newsletter_subscribers_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_newsletter_subscribers_active ON public.newsletter_subscribers USING btree (is_active);


--
-- TOC entry 3658 (class 1259 OID 25069)
-- Name: idx_newsletter_subscribers_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_newsletter_subscribers_email ON public.newsletter_subscribers USING btree (email);


--
-- TOC entry 3659 (class 1259 OID 25070)
-- Name: idx_newsletter_subscribers_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_newsletter_subscribers_source ON public.newsletter_subscribers USING btree (subscription_source);


--
-- TOC entry 3666 (class 1259 OID 25071)
-- Name: idx_pages_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pages_slug ON public.pages USING btree (slug);


--
-- TOC entry 3671 (class 1259 OID 25072)
-- Name: idx_posts_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_date ON public.posts USING btree (date);


--
-- TOC entry 3672 (class 1259 OID 25073)
-- Name: idx_posts_last_edited; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_last_edited ON public.posts USING btree (last_edited_at);


--
-- TOC entry 3673 (class 1259 OID 25074)
-- Name: idx_posts_permission_level; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_permission_level ON public.posts USING btree (permission_level);


--
-- TOC entry 3674 (class 1259 OID 25075)
-- Name: idx_posts_published; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_published ON public.posts USING btree (published);


--
-- TOC entry 3675 (class 1259 OID 25076)
-- Name: idx_posts_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_slug ON public.posts USING btree (slug);


--
-- TOC entry 3676 (class 1259 OID 25077)
-- Name: idx_posts_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_status ON public.posts USING btree (status);


--
-- TOC entry 3681 (class 1259 OID 25078)
-- Name: idx_profiles_home_page_skills; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_profiles_home_page_skills ON public.profiles USING gin (home_page_skills);


--
-- TOC entry 3684 (class 1259 OID 25079)
-- Name: idx_projects_featured; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_featured ON public.projects USING btree (featured);


--
-- TOC entry 3685 (class 1259 OID 25080)
-- Name: idx_projects_last_edited; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_last_edited ON public.projects USING btree (last_edited_at);


--
-- TOC entry 3686 (class 1259 OID 25081)
-- Name: idx_projects_permission_level; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_permission_level ON public.projects USING btree (permission_level);


--
-- TOC entry 3687 (class 1259 OID 25082)
-- Name: idx_projects_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_slug ON public.projects USING btree (slug);


--
-- TOC entry 3688 (class 1259 OID 25083)
-- Name: idx_projects_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_status ON public.projects USING btree (status);


--
-- TOC entry 3697 (class 1259 OID 25084)
-- Name: idx_security_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_security_logs_created_at ON public.security_logs USING btree (created_at);


--
-- TOC entry 3698 (class 1259 OID 25085)
-- Name: idx_security_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_security_logs_user_id ON public.security_logs USING btree (user_id);


--
-- TOC entry 3701 (class 1259 OID 25086)
-- Name: idx_sessions_session_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_session_token ON public.sessions USING btree (session_token);


--
-- TOC entry 3702 (class 1259 OID 25087)
-- Name: idx_sessions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_user_id ON public.sessions USING btree (user_id);


--
-- TOC entry 3715 (class 1259 OID 25088)
-- Name: idx_user_access_levels_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_access_levels_email ON public.user_access_levels USING btree (email);


--
-- TOC entry 3716 (class 1259 OID 25089)
-- Name: idx_user_access_levels_personal; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_access_levels_personal ON public.user_access_levels USING btree (has_personal_access);


--
-- TOC entry 3717 (class 1259 OID 25090)
-- Name: idx_user_access_levels_professional; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_access_levels_professional ON public.user_access_levels USING btree (has_professional_access);


--
-- TOC entry 3722 (class 1259 OID 25091)
-- Name: idx_user_activity_log_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_activity_log_action ON public.user_activity_log USING btree (action);


--
-- TOC entry 3723 (class 1259 OID 25092)
-- Name: idx_user_activity_log_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_activity_log_created_at ON public.user_activity_log USING btree (created_at);


--
-- TOC entry 3724 (class 1259 OID 25093)
-- Name: idx_user_activity_log_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_activity_log_user_id ON public.user_activity_log USING btree (user_id);


--
-- TOC entry 3727 (class 1259 OID 25094)
-- Name: idx_user_login_sessions_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_login_sessions_expires_at ON public.user_login_sessions USING btree (expires_at);


--
-- TOC entry 3728 (class 1259 OID 25095)
-- Name: idx_user_login_sessions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_login_sessions_user_id ON public.user_login_sessions USING btree (user_id);


--
-- TOC entry 3731 (class 1259 OID 25096)
-- Name: idx_user_permissions_permission_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_permissions_permission_name ON public.user_permissions USING btree (permission_name);


--
-- TOC entry 3732 (class 1259 OID 25097)
-- Name: idx_user_permissions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_permissions_user_id ON public.user_permissions USING btree (user_id);


--
-- TOC entry 3737 (class 1259 OID 25098)
-- Name: idx_user_role_history_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_role_history_user_id ON public.user_role_history USING btree (user_id);


--
-- TOC entry 3744 (class 1259 OID 25099)
-- Name: idx_verification_tokens_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_verification_tokens_token ON public.verification_tokens USING btree (token);


--
-- TOC entry 3781 (class 2620 OID 25100)
-- Name: categories update_categories_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_categories_updated_at BEFORE UPDATE ON public.categories FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3782 (class 2620 OID 25101)
-- Name: content_comments update_content_comments_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_content_comments_updated_at BEFORE UPDATE ON public.content_comments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3783 (class 2620 OID 25102)
-- Name: content_drafts update_content_drafts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_content_drafts_updated_at BEFORE UPDATE ON public.content_drafts FOR EACH ROW EXECUTE FUNCTION public.update_last_edited_at();


--
-- TOC entry 3784 (class 2620 OID 25103)
-- Name: content_templates update_content_templates_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_content_templates_updated_at BEFORE UPDATE ON public.content_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3785 (class 2620 OID 25104)
-- Name: newsletter_content update_newsletter_content_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_newsletter_content_updated_at BEFORE UPDATE ON public.newsletter_content FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3786 (class 2620 OID 25105)
-- Name: newsletter_templates update_newsletter_templates_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_newsletter_templates_updated_at BEFORE UPDATE ON public.newsletter_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3787 (class 2620 OID 25106)
-- Name: pages update_pages_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_pages_updated_at BEFORE UPDATE ON public.pages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3788 (class 2620 OID 25107)
-- Name: posts update_posts_last_edited_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_posts_last_edited_at BEFORE UPDATE ON public.posts FOR EACH ROW EXECUTE FUNCTION public.update_last_edited_at();


--
-- TOC entry 3789 (class 2620 OID 25108)
-- Name: posts update_posts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_posts_updated_at BEFORE UPDATE ON public.posts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3790 (class 2620 OID 25109)
-- Name: profiles update_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3791 (class 2620 OID 25110)
-- Name: projects update_projects_last_edited_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_projects_last_edited_at BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.update_last_edited_at();


--
-- TOC entry 3792 (class 2620 OID 25111)
-- Name: projects update_projects_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3793 (class 2620 OID 25112)
-- Name: roles update_roles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_roles_updated_at BEFORE UPDATE ON public.roles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3794 (class 2620 OID 25113)
-- Name: user_2fa_settings update_user_2fa_settings_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_user_2fa_settings_updated_at BEFORE UPDATE ON public.user_2fa_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3749 (class 2606 OID 25114)
-- Name: access_requests access_requests_processed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_requests
    ADD CONSTRAINT access_requests_processed_by_fkey FOREIGN KEY (processed_by) REFERENCES public.users(id);


--
-- TOC entry 3750 (class 2606 OID 25119)
-- Name: accounts accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3751 (class 2606 OID 25124)
-- Name: bulk_operations_log bulk_operations_log_performed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bulk_operations_log
    ADD CONSTRAINT bulk_operations_log_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES public.users(id);


--
-- TOC entry 3752 (class 2606 OID 25129)
-- Name: content_collaborators content_collaborators_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_collaborators
    ADD CONSTRAINT content_collaborators_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.users(id);


--
-- TOC entry 3753 (class 2606 OID 25134)
-- Name: content_collaborators content_collaborators_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_collaborators
    ADD CONSTRAINT content_collaborators_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3754 (class 2606 OID 25139)
-- Name: content_comments content_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_comments
    ADD CONSTRAINT content_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3755 (class 2606 OID 25144)
-- Name: content_drafts content_drafts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_drafts
    ADD CONSTRAINT content_drafts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 3756 (class 2606 OID 25149)
-- Name: content_versions content_versions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_versions
    ADD CONSTRAINT content_versions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 3757 (class 2606 OID 25154)
-- Name: media_files media_files_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- TOC entry 3758 (class 2606 OID 25159)
-- Name: media_folders media_folders_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_folders
    ADD CONSTRAINT media_folders_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.media_folders(id) ON DELETE CASCADE;


--
-- TOC entry 3759 (class 2606 OID 25164)
-- Name: newsletter_analytics newsletter_analytics_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_analytics
    ADD CONSTRAINT newsletter_analytics_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.newsletter_campaigns(id) ON DELETE CASCADE;


--
-- TOC entry 3760 (class 2606 OID 25169)
-- Name: newsletter_analytics newsletter_analytics_subscriber_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_analytics
    ADD CONSTRAINT newsletter_analytics_subscriber_id_fkey FOREIGN KEY (subscriber_id) REFERENCES public.newsletter_subscribers(id) ON DELETE CASCADE;


--
-- TOC entry 3761 (class 2606 OID 25174)
-- Name: newsletter_automation_rules newsletter_automation_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_automation_rules
    ADD CONSTRAINT newsletter_automation_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 3762 (class 2606 OID 25179)
-- Name: newsletter_automation_rules newsletter_automation_rules_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_automation_rules
    ADD CONSTRAINT newsletter_automation_rules_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.newsletter_templates(id);


--
-- TOC entry 3763 (class 2606 OID 25184)
-- Name: newsletter_campaigns newsletter_campaigns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_campaigns
    ADD CONSTRAINT newsletter_campaigns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 3764 (class 2606 OID 25189)
-- Name: newsletter_campaigns newsletter_campaigns_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_campaigns
    ADD CONSTRAINT newsletter_campaigns_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.newsletter_templates(id);


--
-- TOC entry 3765 (class 2606 OID 25194)
-- Name: newsletter_templates newsletter_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletter_templates
    ADD CONSTRAINT newsletter_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 3766 (class 2606 OID 25199)
-- Name: posts posts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 3767 (class 2606 OID 25204)
-- Name: posts posts_last_edited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_last_edited_by_fkey FOREIGN KEY (last_edited_by) REFERENCES public.users(id);


--
-- TOC entry 3768 (class 2606 OID 25209)
-- Name: projects projects_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 3769 (class 2606 OID 25214)
-- Name: projects projects_last_edited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_last_edited_by_fkey FOREIGN KEY (last_edited_by) REFERENCES public.users(id);


--
-- TOC entry 3770 (class 2606 OID 25219)
-- Name: security_logs security_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_logs
    ADD CONSTRAINT security_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3771 (class 2606 OID 25224)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3772 (class 2606 OID 25229)
-- Name: user_2fa_settings user_2fa_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_2fa_settings
    ADD CONSTRAINT user_2fa_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3773 (class 2606 OID 25234)
-- Name: user_access_levels user_access_levels_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_access_levels
    ADD CONSTRAINT user_access_levels_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- TOC entry 3774 (class 2606 OID 25239)
-- Name: user_access_levels user_access_levels_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_access_levels
    ADD CONSTRAINT user_access_levels_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3775 (class 2606 OID 25244)
-- Name: user_activity_log user_activity_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT user_activity_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3776 (class 2606 OID 25249)
-- Name: user_login_sessions user_login_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_login_sessions
    ADD CONSTRAINT user_login_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3777 (class 2606 OID 25254)
-- Name: user_permissions user_permissions_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- TOC entry 3778 (class 2606 OID 25259)
-- Name: user_permissions user_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3779 (class 2606 OID 25264)
-- Name: user_role_history user_role_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_role_history
    ADD CONSTRAINT user_role_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- TOC entry 3780 (class 2606 OID 25269)
-- Name: user_role_history user_role_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_role_history
    ADD CONSTRAINT user_role_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3977 (class 0 OID 0)
-- Dependencies: 221
-- Name: TABLE content_drafts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.content_drafts TO PUBLIC;


-- Completed on 2025-10-24 20:24:34 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict kjghHhrwURYiYxX5fpyK2H0QdJyINfS5l1AbwPUiRieyHVEO77QGnFS44IlqgDX

